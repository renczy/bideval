# BidEval – Windows fiktív teszt

Ez a csomag helyben, a saját gépeden fut. Nem éles publikálás. Céges Word-sablont, eredeti dokumentumot, dokumentummintát, aláírást vagy személyes fiókot nem tartalmaz.

## Első indítás

1. A letöltött ZIP-en jobb kattintás → Az összes kibontása. Ne a ZIP-en belül indítsd el.
2. Telepíts Node.js 24 LTS vagy újabb változatot a https://nodejs.org/ oldalról (Windows Installer, alapértelmezett telepítés). Ha már telepítve van, nem kell újra.
3. A kibontott BidEval-teszt mappában kattints duplán az INDITAS-TESZT.cmd fájlra. Első alkalommal internetkapcsolattal telepíti a függőségeket. Az ablakot hagyd nyitva.
4. A böngészőben megnyíló helyi útmutatóban másold ki a telepítési tokent. Ha nem nyílik meg, nyisd meg a teszt-adatok/elso-belepes.html fájlt.
5. Az útmutató alkalmazásra mutató hivatkozásával nyisd meg a felületet. A Telepítési token mezőbe illeszd be a tokent, majd add meg saját e-mail-címedet és egy legalább 12 karakteres jelszót. Kattints a Fiók létrehozása gombra. A jelszót csak ebben a helyi űrlapban add meg, chatben ne!

Később e-mail/jelszóval jelentkezz be; a telepítési tokenre nincs többé szükség. Leállítás: Ctrl+C az indítóablakban. Újraindítás: ismét dupla kattintás az INDITAS-TESZT.cmd fájlra. A tesztadatok megmaradnak.

## Előkészített fiktív ügy

Válaszd a FIKTÍV TESZT – granulátum és szállítás ügyet. Három fiktív ajánlattevő és három ártétel már mentve van. A súlyok 90, 5, 5; a módszer Súlyozott összehasonlító ár. Az érték egységár × súly, majd összegzés; a kisebb érték kedvezőbb. Ez nem a szerződéses ár.

Elvárt rangsor: Fiktív Alfa 11 500; Fiktív Béta 12 100; Fiktív Gamma 12 150. Nettó összegek: 1500, 1700, 1550 Ft. A feltételek véglegesítettek, de a döntési javaslat még nincs jóváhagyva.

A 3. Bírálat és döntés fülön ellenőrizd a rangsort. A jóváhagyáshoz töltsd ki az indokolást, műszaki tartalmat, bírálói nevet/munkakört, helyet/dátumot és szerződési adatokat. Kizárólag fiktív adatot használj! Például Fiktív Bíráló; Tesztelő; Tesztváros; 2026. november; egyedi szerződés; 1500 Ft. Jóváhagyás után az ügy zárolt. A 4. Dokumentumok fülön az Összehasonlító Excel letölthető.

## Új fiktív ügy létrehozása

1. Új beszerzés → tárgy, azonosító, szervezet és becsült nettó érték → Beszerzés létrehozása.
2. 1. Előkészítés → módszer kiválasztása, tételek, mennyiség, egység, súly/pontmaximum és megfelelőségi követelmények. Feltételek mentése, majd Mentett feltételek véglegesítése. Véglegesítés után a módszer nem módosítható.
3. 2. Ajánlatok → partner neve, Partner felvétele; státusz, megfelelőség, nettó egységárak és megjegyzés → Új ajánlatverzió mentése. Tárgyalási árat új verzióként ments.
4. 3. Bírálat és döntés → rangsor ellenőrzése, nyertes kiválasztása, indokolás és döntési/szerződési adatok → Döntési javaslat jóváhagyása. Háromnál kevesebb értékelhető ajánlatnál külön indokolás szükséges.
5. 4. Dokumentumok → Összehasonlító Excel.

## DOCX és PDF ebben a megosztható csomagban

A céges sablont és a korábbi dokumentummintákat szándékosan kihagytuk. Ezért a hivatalos DOCX/PDF-export sablon nélkül blokkolt. A kitöltött eredeti példát ne töltsd fel sablonként. A külön megtisztított, mezőzött, vállalatilag ellenőrzött sablon helyben az Adminisztráció felületen tölthető fel és hagyható jóvá. A jóváhagyás a formát és a hatályosságot is igazolja, ezért csak tényleges ellenőrzés után add meg. A vállalati sablon későbbi átadása külön, privát csatornát igényel.

PDF készítéséhez stabil LibreOffice szükséges: https://www.libreoffice.org/download/download-libreoffice/ . Alapértelmezett Windows-telepítést az indító automatikusan felismer. Jóváhagyott sablonnal az ügy 4. fülén Sablonverzió → Bírálati lap (DOCX) vagy PDF-előnézet. A PDF-előnézet gomb letölti a PDF-et. LibreOffice nem szükséges a felülethez vagy az XLSX-exporthoz.

## Elkülönítés és felhasználók

Külön tesztadatbázis: teszt-adatok/bideval.sqlite. Ebben csak fiktív ügyadatok vannak; a személyes tesztfiókodat te hozod létre. Éles adatbázisként ezt nem szabad használni. A normál alkalmazás külön .data/bideval.sqlite fájlt használ.

Helyi Node/Express, React, SQLite, sózott scrypt jelszóhash, HttpOnly munkamenet és admin/bíráló/megtekintő szerepkörök működnek. A privát fájlok és exportok helyben tárolódnak. Nincs nyilvános regisztráció vagy e-mail küldés. Supabase Auth, PostgreSQL/RLS, Storage, e-mailes meghívás/visszaállítás és RPC/Edge Functions még nincsenek bekötve; további integrációt igényelnek. A helyi módhoz nem kell Supabase-kulcs.

## Hibajelzés és ellenőrzési határ

A HIBAJELENTES.txt mintát töltsd ki: képernyő, lépések, várt eredmény, tényleges eredmény, pontos hibaüzenet. Fiktív adatot mutató képernyőképet küldhetsz. Jelszó, token, cookie vagy első-belépési útmutató ne kerüljön a hibajelentésbe.

A Node-indítást, a fiktív ügyet, az admin-regisztrációt, a bírálatot és az XLSX-letöltést Linux/Chromium alatt ellenőriztük. A Windows CMD-indító és a Microsoft Office alatti megnyitás a felhasználói kipróbálásban ellenőrizendő. Ha nem indul, az indítóablak hibaüzenetét küldd el, titkok nélkül. Ha a port foglalt, zárd be a korábbi tesztindító ablakot.

A következő lépésed: kibontás, INDITAS-TESZT.cmd indítása, személyes tesztadmin létrehozása. Éles publikálás nem történik.
