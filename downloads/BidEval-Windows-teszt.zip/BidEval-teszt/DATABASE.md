# Adatmodell

## Működő SQLite-mód

`server/index.js` inicializálja a központi táblákat, `server/schema.sql` a normalizált relációkat.

| Tábla                | Tartalom                                                        |
| -------------------- | --------------------------------------------------------------- |
| users                | E-mail, sózott scrypt hash, szerepkör, hozzáférési állapot      |
| sessions             | Token hash, user FK, lejárat                                    |
| procurements         | Tulajdonos FK, ügyadatok JSON olvasási modellje                 |
| memberships          | Ügy és user összetett kulcs; ügyhozzáférés                      |
| line_items           | Dinamikus tételek, pontos szöveges mennyiség és súly            |
| requirements         | Ügyenként előzetesen rögzített feltételek                       |
| bidders              | Dinamikus partnerek, benyújtás és megfelelőség külön státusszal |
| bid_versions         | Eredeti/hiánypótlási/tárgyalási verzió; append-only             |
| bid_prices           | Verzió × tétel összetett kulcs, egységár szöveg                 |
| compliance_checks    | Ajánlattevő × követelmény, státusz és indokolás                 |
| evaluation_setups    | Véglegesített módszer változtathatatlan pillanatképe            |
| evaluation_snapshots | Jóváhagyott bírálat, verziók és emberi döntés                   |
| templates            | Verzió, DOCX, SHA-256 és jóváhagyó/időpont                      |
| generated_exports    | Archivált DOCX/PDF/XLSX, pillanatkép és sablon FK               |
| documents            | Privát fájl, ügy FK, partnerazonosító                           |
| audit                | Szereplő, művelet, időpont és az adott állapot adatai           |

A JSON olvasási modell és a normalizált sorok ugyanazon tranzakcióban frissülnek. A korábbi ajánlatverziók nem törlődnek. A megfelelőségi módosítások előzménye az auditban megmarad. Az alkalmazás nem kínál ügy-/ajánlat-/audit-törlést. Ez nem kriptográfiai vagy szabályozói szintű megváltoztathatatlan napló: a gép adatbázis-adminisztrátora az adatállományhoz hozzáfér.

## Tervezett Supabase-mód

A `supabase/migrations/001_initial.sql` előkészített normalizált célséma és RLS-kiindulópont. Nem futott le konfigurált Supabase-projekten; frontend/API adapter és tranzakciós műveletek még szükségesek. Privát tárolási útvonal: `<procurement_id>/<document_id>/<filename>`. A role mezőt csak admin módosíthatja; kliens nem emelheti saját szerepkörét.

## Mentés és visszaállítás

A `.data/bideval.sqlite` bizalmas adatokat tartalmazhat; Gitbe nem kerülhet. Mentéskor állítsd le a helyi szervert, másold az állományt védett helyre, majd indítsd újra. Más működő adatbázist ne írj felül. Éles üzemhez titkosított mentés, visszaállítási próba és adatmegőrzési szabályzat szükséges.
