import { number } from "../server/evaluation.js";
/** Format the decimal text directly, without converting financial values to binary floats. */
export function money(value: string | number | undefined, places = 3): string {
  if (value === undefined) return "—";
  const [integer, fraction] = number(value).fixed(places).split(".");
  const grouped = integer.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  const decimals = fraction?.replace(/0+$/, "");
  return grouped + (decimals ? "," + decimals : "");
}
