import React, { useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import {
  LayoutDashboard,
  BriefcaseBusiness,
  FileText,
  ShieldCheck,
  LogOut,
  Plus,
  ArrowRight,
  CheckCircle2,
  Scale,
  ChevronLeft,
  Download,
  LockKeyhole,
} from "lucide-react";
import "./style.css";
import { money } from "./format";
type Data = any;
const methods: Data = {
  lowest: "Legalacsonyabb összesített ár",
  weighted: "Súlyozott összehasonlító ár",
  points: "Súlyozott pontozás",
};
const statuses: Data = {
  pass: "Megfelel",
  fail: "Nem felel meg",
  clarify: "Tisztázandó",
  pending: "Még nem vizsgált",
  na: "Nem alkalmazható",
};
async function api(url: string, body?: any, method?: string) {
  const r = await fetch("/api" + url, {
    method: method || (body ? "POST" : "GET"),
    headers:
      body instanceof FormData
        ? undefined
        : { "Content-Type": "application/json" },
    body: body
      ? body instanceof FormData
        ? body
        : JSON.stringify(body)
      : undefined,
  });
  const data = await r.json();
  if (!r.ok) throw Error(data.error || "Sikertelen kérés");
  return data;
}
function App() {
  const [user, setUser] = useState<Data>(null),
    [bootstrap, setBootstrap] = useState(false),
    [error, setError] = useState(""),
    [page, setPage] = useState("overview"),
    [list, setList] = useState<Data[]>([]),
    [selected, setSelected] = useState<Data>(null),
    [tab, setTab] = useState("setup"),
    [result, setResult] = useState<Data>(null),
    [templates, setTemplates] = useState<Data[]>([]),
    [search, setSearch] = useState(""),
    [phaseFilter, setPhaseFilter] = useState("all"),
    [sort, setSort] = useState("newest"),
    [busy, setBusy] = useState(false);
  const act = async (fn: () => Promise<any>) => {
    setError("");
    setBusy(true);
    try {
      return await fn();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const refresh = async () => setList(await api("/procurements"));
  useEffect(() => {
    api("/status").then((s) => setBootstrap(s.bootstrap));
    api("/me")
      .then(setUser)
      .catch(() => {});
  }, []);
  useEffect(() => {
    if (user) {
      refresh();
      api("/templates").then(setTemplates);
    }
  }, [user]);
  const open = async (p: Data) => {
    setSelected(await api("/procurements/" + p.id));
    setResult(null);
    setTab(p.phase === "setup" ? "setup" : "bids");
    setPage("procurements");
  };
  const mutate = async (route: string, body?: Data, method?: string) => {
    const p = await api("/procurements/" + selected.id + route, body, method);
    setSelected(p);
    await refresh();
    return p;
  };
  const writable = user?.role !== "viewer";
  if (!user)
    return (
      <div className="auth">
        <div className="auth-brand">
          <div className="logo">
            <Scale /> BidEval
          </div>
          <h1>
            Átlátható bírálat.
            <br />
            Megalapozott döntés.
          </h1>
          <p>
            Beszerzési ajánlatok, pontos számítások és ellenőrizhető döntési
            javaslatok egy helyen.
          </p>
          <div className="auth-note">
            <ShieldCheck /> Meghívásos hozzáférés · Privát dokumentumok
          </div>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const f = Object.fromEntries(new FormData(e.currentTarget));
            act(async () => {
              if (bootstrap) {
                await api("/bootstrap", f);
                setBootstrap(false);
              }
              setUser(await api("/login", f));
            });
          }}
        >
          <div className="eyebrow">BESZERZÉSI DÖNTÉSTÁMOGATÁS</div>
          <h2>
            {bootstrap
              ? "Adminisztrátor létrehozása"
              : "Üdvözöljük a BidEvalban"}
          </h2>
          <p>
            {bootstrap
              ? "Az első fiók létrehozásához a szerver telepítési tokenje szükséges."
              : "Jelentkezzen be a munkája folytatásához."}
          </p>
          {bootstrap && (
            <label>
              Telepítési token
              <input name="token" type="password" required autoComplete="off" />
            </label>
          )}
          <label>
            E-mail-cím
            <input name="email" type="email" required autoComplete="username" />
          </label>
          <label>
            Jelszó
            <input
              name="password"
              type="password"
              minLength={bootstrap ? 12 : 1}
              required
              autoComplete={bootstrap ? "new-password" : "current-password"}
            />
          </label>
          {error && (
            <div role="alert" className="error">
              {error}
            </div>
          )}
          <button disabled={busy}>
            {" "}
            {bootstrap ? "Fiók létrehozása" : "Bejelentkezés"}{" "}
            <ArrowRight size={17} />
          </button>
          <small>Nyilvános regisztráció nem engedélyezett.</small>
        </form>
      </div>
    );
  return (
    <div className="shell">
      <aside>
        <div className="logo">
          <Scale /> BidEval
        </div>
        <div className="workspace">BESZERZÉSI MUNKATÉR</div>
        <nav>
          {[
            ["overview", "Áttekintés", LayoutDashboard],
            ["procurements", "Beszerzések", BriefcaseBusiness],
            ["documents", "Dokumentumok", FileText],
            ["account", "Saját fiók", LockKeyhole],
            ["admin", "Adminisztráció", ShieldCheck],
          ]
            .filter(([id]) => id !== "admin" || user.role === "admin")
            .map(([id, label, Icon]: any) => (
              <button
                key={id}
                className={page === id ? "active" : ""}
                onClick={() => {
                  setPage(id);
                  setSelected(null);
                }}
              >
                <Icon size={19} />
                {label}
              </button>
            ))}
        </nav>
        <div className="side-bottom">
          <div className="avatar">{user.email[0].toUpperCase()}</div>
          <div>
            <b>{user.email}</b>
            <small>
              {user.role === "admin"
                ? "Adminisztrátor"
                : user.role === "viewer"
                  ? "Megtekintő"
                  : "Bíráló"}
            </small>
          </div>
          <button
            className="icon"
            aria-label="Kijelentkezés"
            onClick={() =>
              act(async () => {
                await api("/logout", {});
                setUser(null);
              })
            }
          >
            <LogOut size={17} />
          </button>
        </div>
      </aside>
      <main>
        <header>
          <span>
            BidEval{" "}
            <span className="muted">
              /{" "}
              {page === "overview"
                ? "Áttekintés"
                : page === "admin"
                  ? "Adminisztráció"
                  : page === "documents"
                    ? "Dokumentumok"
                    : "Beszerzések"}
            </span>
          </span>
          <span className="private">
            <LockKeyhole size={13} /> Privát munkatér
          </span>
        </header>
        <div className="content">
          {error && (
            <div role="alert" className="error">
              {error}
              <button className="icon" onClick={() => setError("")}>
                ×
              </button>
            </div>
          )}
          {busy && (
            <div className="working" role="status">
              Művelet folyamatban…
            </div>
          )}
          {!selected && ["overview", "procurements"].includes(page) && (
            <>
              <div className="page-head">
                <div>
                  <div className="eyebrow">
                    {page === "overview" ? "MUNKATÉR" : "BESZERZÉSI ÜGYEK"}
                  </div>
                  <h1>{page === "overview" ? "Áttekintés" : "Beszerzések"}</h1>
                  <p>
                    Kövesse az ajánlatok útját az előkészítéstől a döntési
                    javaslatig.
                  </p>
                </div>
                {writable && (
                  <button
                    onClick={() => {
                      setPage("new");
                    }}
                  >
                    <Plus size={18} /> Új beszerzés
                  </button>
                )}
              </div>
              <div className="stats">
                {[
                  [
                    "Összes beszerzés",
                    list.length,
                    "Az Ön számára elérhető ügyek",
                  ],
                  [
                    "Előkészítés alatt",
                    list.filter((p) => p.phase === "setup").length,
                    "Értékelési feltételek összeállítása",
                  ],
                  [
                    "Bírálat folyamatban",
                    list.filter((p) => p.phase === "bids").length,
                    "Ajánlatok és megfelelőség",
                  ],
                  [
                    "Jóváhagyott javaslat",
                    list.filter((p) => p.phase === "approved").length,
                    "Rögzített értékelési pillanatképek",
                  ],
                ].map(([label, value, note]) => (
                  <div className="stat" key={label}>
                    <span>{label}</span>
                    <strong>{value}</strong>
                    <small>{note}</small>
                  </div>
                ))}
              </div>
              <div className="panel">
                <div className="panel-title">
                  <h2>Beszerzési ügyek</h2>
                  <input
                    placeholder="Keresés tárgy vagy azonosító szerint…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                  <select
                    aria-label="Állapotszűrő"
                    value={phaseFilter}
                    onChange={(e) => setPhaseFilter(e.target.value)}
                  >
                    <option value="all">Minden állapot</option>
                    <option value="setup">Előkészítés</option>
                    <option value="bids">Bírálat</option>
                    <option value="approved">Jóváhagyott</option>
                  </select>
                  <select
                    aria-label="Rendezés"
                    value={sort}
                    onChange={(e) => setSort(e.target.value)}
                  >
                    <option value="newest">Legújabb elöl</option>
                    <option value="title">Tárgy szerint</option>
                  </select>
                </div>
                {list.length === 0 ? (
                  <div className="empty">
                    <BriefcaseBusiness size={36} />
                    <h3>Itt kezdődik a következő beszerzés</h3>
                    <p>
                      Hozzon létre egy ügyet, és rögzítse előre az értékelési
                      feltételeket.
                    </p>
                  </div>
                ) : (
                  <div className="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>Beszerzés tárgya</th>
                          <th>Azonosító</th>
                          <th>Értékelési módszer</th>
                          <th>Állapot</th>
                          <th>Ajánlattevők</th>
                          <th />
                        </tr>
                      </thead>
                      <tbody>
                        {list
                          .filter((p) =>
                            (p.title + " " + p.reference)
                              .toLowerCase()
                              .includes(search.toLowerCase()),
                          )
                          .filter(
                            (p) =>
                              phaseFilter === "all" || p.phase === phaseFilter,
                          )
                          .sort((a, b) =>
                            sort === "title"
                              ? a.title.localeCompare(b.title, "hu")
                              : String(b.createdAt || "").localeCompare(
                                  String(a.createdAt || ""),
                                ),
                          )
                          .map((p) => (
                            <tr key={p.id} onClick={() => act(() => open(p))}>
                              <td>
                                <b>{p.title}</b>
                                <small>
                                  {p.organization || "Szervezet nincs megadva"}
                                </small>
                              </td>
                              <td>{p.reference || "—"}</td>
                              <td>{methods[p.method]}</td>
                              <td>
                                <span className={"badge " + p.phase}>
                                  {p.phase === "setup"
                                    ? "Előkészítés"
                                    : p.phase === "bids"
                                      ? "Bírálat"
                                      : "Jóváhagyott"}
                                </span>
                              </td>
                              <td>{p.bidders.length}</td>
                              <td>
                                <ArrowRight size={17} />
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
              <div className="info">
                <ShieldCheck />
                <div>
                  <b>A döntés az Ön kezében marad</b>
                  <p>
                    A rangsor matematikai javaslat. Nyertes kizárólag
                    dokumentált bírálói döntéssel jelölhető.
                  </p>
                </div>
              </div>
            </>
          )}
          {page === "new" && (
            <>
              <h1>Új beszerzés</h1>
              <form
                className="panel form"
                onSubmit={(e) => {
                  e.preventDefault();
                  const f = Object.fromEntries(new FormData(e.currentTarget));
                  act(async () => {
                    const p = await api("/procurements", f);
                    await refresh();
                    await open(p);
                  });
                }}
              >
                <label>
                  Beszerzés tárgya
                  <input name="title" required />
                </label>
                <div className="grid">
                  <label>
                    Eljárás azonosítója
                    <input name="reference" required />
                  </label>
                  <label>
                    Kezdeményező szervezet
                    <input name="organization" required />
                  </label>
                  <label>
                    Becsült nettó érték (Ft)
                    <input
                      name="estimate"
                      type="number"
                      min="0"
                      step="0.01"
                      required
                    />
                  </label>
                </div>
                <button disabled={busy}>
                  Beszerzés létrehozása <ArrowRight size={17} />
                </button>
              </form>
            </>
          )}
          {selected && (
            <>
              <button className="text-button" onClick={() => setSelected(null)}>
                <ChevronLeft size={16} /> Vissza a beszerzésekhez
              </button>
              <div className="page-head">
                <div>
                  <div className="eyebrow">
                    {selected.reference || "BESZERZÉS"}
                  </div>
                  <h1>{selected.title}</h1>
                  <p>
                    {selected.organization} · Becsült nettó érték:{" "}
                    {money(selected.estimate)} Ft
                  </p>
                </div>
                <span className={"badge " + selected.phase}>
                  {selected.phase === "setup"
                    ? "Előkészítés"
                    : selected.phase === "bids"
                      ? "Bírálat folyamatban"
                      : "Jóváhagyott javaslat"}
                </span>
              </div>
              <div className="tabs">
                {[
                  ["setup", "1. Előkészítés"],
                  ["bids", "2. Ajánlatok"],
                  ["evaluation", "3. Bírálat és döntés"],
                  ["exports", "4. Dokumentumok"],
                  ["audit", "Előzmények"],
                ].map(([id, label]) => (
                  <button
                    className={tab === id ? "active" : ""}
                    key={id}
                    onClick={() => {
                      setTab(id);
                      if (id === "evaluation" && selected.items.length)
                        act(async () =>
                          setResult(
                            await api(
                              "/procurements/" + selected.id + "/evaluation",
                            ),
                          ),
                        );
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
              {tab === "setup" && (
                <Setup
                  key={selected.id + ":" + selected.revision}
                  p={selected}
                  writable={writable}
                  onSave={(b: any) => act(() => mutate("/setup", b, "PUT"))}
                  onFinalize={() => act(() => mutate("/finalize", {}))}
                />
              )}
              {tab === "bids" && (
                <>
                  <div className="panel form">
                    <h2>Ajánlattételre felkért partnerek</h2>
                    {writable && !selected.snapshot && (
                      <form
                        className="inline"
                        onSubmit={(e) => {
                          e.preventDefault();
                          const name = new FormData(e.currentTarget).get(
                            "name",
                          );
                          e.currentTarget.reset();
                          act(() => mutate("/bidders", { name }));
                        }}
                      >
                        <input
                          name="name"
                          placeholder="Ajánlattevő neve"
                          required
                        />
                        <button>
                          <Plus size={16} /> Partner felvétele
                        </button>
                      </form>
                    )}
                    {selected.phase === "setup" && (
                      <p className="notice">
                        Árak rögzítése előtt véglegesítse az értékelési
                        feltételeket.
                      </p>
                    )}
                  </div>
                  {selected.bidders.map((b: Data) => (
                    <Bid
                      key={b.id + ":" + selected.revision}
                      b={b}
                      p={selected}
                      writable={writable}
                      onSave={(data: Data) =>
                        act(() => mutate("/bidders/" + b.id, data))
                      }
                      onImport={(f: FormData) =>
                        act(() =>
                          api(
                            "/procurements/" +
                              selected.id +
                              "/bidders/" +
                              b.id +
                              "/import",
                            f,
                          ),
                        )
                      }
                      onUpload={(f: FormData) =>
                        act(() =>
                          api(
                            "/procurements/" +
                              selected.id +
                              "/documents/" +
                              b.id,
                            f,
                          ),
                        )
                      }
                    />
                  ))}
                </>
              )}
              {tab === "evaluation" && (
                <>
                  <div className="panel form">
                    <div className="panel-title">
                      <h2>Értékelési rangsor</h2>
                      <button
                        className="secondary"
                        onClick={() =>
                          act(async () =>
                            setResult(
                              await api(
                                "/procurements/" + selected.id + "/evaluation",
                              ),
                            ),
                          )
                        }
                      >
                        Újraszámítás
                      </button>
                    </div>
                    <p>
                      {methods[selected.method]} · A súlyozott érték nem
                      szerződéses ár.
                    </p>
                    {result && (
                      <>
                        <div className="table-wrap">
                          <table>
                            <thead>
                              <tr>
                                <th>Rang</th>
                                <th>Ajánlattevő</th>
                                <th>Nettó összeg (Ft)</th>
                                <th>
                                  {selected.method === "points"
                                    ? "Pontszám"
                                    : "Összehasonlító érték"}
                                </th>
                                <th>Megállapítás</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.rows.map((r: Data) => (
                                <tr key={r.id}>
                                  <td>{r.rank || "—"}</td>
                                  <td>
                                    <b>{r.name}</b>
                                  </td>
                                  <td>
                                    {money(
                                      r.total,
                                      selected.decimalPlaces ?? 3,
                                    )}
                                  </td>
                                  <td>
                                    {money(
                                      r.value,
                                      selected.decimalPlaces ?? 3,
                                    )}
                                  </td>
                                  <td>{r.reason || "Értékelhető"}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        {result.tie && (
                          <p className="notice">
                            Holtverseny: dokumentált bírálói döntés szükséges.
                          </p>
                        )}
                        {result.needsClarification && (
                          <p className="error">
                            Nulla ár miatt a pontozás nem végezhető el.
                            Tisztázás szükséges.
                          </p>
                        )}
                      </>
                    )}
                  </div>
                  {selected.snapshot ? (
                    <div className="panel form">
                      <CheckCircle2 />
                      <h2>Jóváhagyott döntési javaslat</h2>
                      <p>{selected.snapshot.decision.reason}</p>
                      <small>Pillanatkép: {selected.snapshot.id}</small>
                    </div>
                  ) : (
                    writable &&
                    result?.ranked.length > 0 && (
                      <form
                        className="panel form"
                        onSubmit={(e) => {
                          e.preventDefault();
                          const d = Object.fromEntries(
                            new FormData(e.currentTarget),
                          );
                          act(() => mutate("/approve", d));
                        }}
                      >
                        <h2>Bírálói döntési javaslat</h2>
                        <p>
                          A jóváhagyás lezárja az ügy adatait és közös
                          exportpillanatképet hoz létre.
                        </p>
                        <label>
                          Nyertesnek javasolt ajánlattevő
                          <select name="winner">
                            {result.ranked.map((r: Data) => (
                              <option key={r.id} value={r.id}>
                                {r.name} · {r.rank}. hely
                              </option>
                            ))}
                          </select>
                        </label>
                        <label>
                          Szakmai és pénzügyi indokolás
                          <textarea name="reason" required />
                        </label>
                        <label>
                          Nyertes ajánlat főbb műszaki tartalma
                          <textarea name="technical" required />
                        </label>
                        <div className="grid">
                          <label>
                            Bíráló neve
                            <input name="reviewer" required />
                          </label>
                          <label>
                            Munkakör
                            <input name="job" required />
                          </label>
                          <label>
                            Készítés helye
                            <input name="place" required />
                          </label>
                          <label>
                            Bírálat ideje
                            <input name="evaluationDate" type="date" required />
                          </label>
                        </div>
                        <div className="grid">
                          <label>
                            Szerződés tervezett futamideje
                            <input name="contractDuration" required />
                          </label>
                          <label>
                            Szerződés tervezett nettó értéke (Ft)
                            <input name="contractValue" required />
                          </label>
                          <label>
                            Szerződés típusa
                            <select name="contractType">
                              <option value="individual">
                                Egyedi szerződés
                              </option>
                              <option value="framework">Keretszerződés</option>
                            </select>
                          </label>
                        </div>
                        {result.ranked.length < 3 && (
                          <label>
                            Háromnál kevesebb értékelhető ajánlat külön
                            indokolása
                            <textarea
                              name="competitionJustification"
                              required
                            />
                          </label>
                        )}
                        <button disabled={busy}>
                          Döntési javaslat jóváhagyása{" "}
                          <CheckCircle2 size={17} />
                        </button>
                      </form>
                    )
                  )}
                </>
              )}
              {tab === "exports" && (
                <Exports p={selected} templates={templates} act={act} />
              )}
              {tab === "audit" && <History id={selected.id} />}
            </>
          )}
          {page === "documents" && !selected && (
            <div className="panel form">
              <h1>Dokumentumok</h1>
              <p>
                A privát ajánlati dokumentumok és exportok az adott beszerzési
                ügy Dokumentumok lapján érhetők el.
              </p>
              <h2>Jóváhagyott sablonverziók</h2>
              {templates.length ? (
                templates.map((t) => (
                  <p key={t.id}>
                    {t.name} · {t.created} ·{" "}
                    {t.approved
                      ? "Jóváhagyott"
                      : "Előkészített, jóváhagyásra vár"}
                  </p>
                ))
              ) : (
                <p className="notice">
                  Még nincs eredeti DOCX-sablon. A hivatalos bírálati lap
                  formahűsége nincs igazolva.
                </p>
              )}
            </div>
          )}
          {page === "account" && (
            <form
              className="panel form"
              onSubmit={(e) => {
                e.preventDefault();
                const f = Object.fromEntries(new FormData(e.currentTarget));
                act(async () => {
                  await api("/password", f);
                  setUser(null);
                });
              }}
            >
              <h1>Saját fiók</h1>
              <p>
                Jelszócsere után minden munkamenet megszűnik. Az új jelszóval
                jelentkezzen be újra.
              </p>
              <label>
                Jelenlegi jelszó
                <input
                  name="current"
                  type="password"
                  autoComplete="current-password"
                  required
                />
              </label>
              <label>
                Új jelszó
                <input
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  minLength={12}
                  required
                />
              </label>
              <button>Jelszó módosítása</button>
            </form>
          )}
          {page === "admin" && (
            <Admin
              act={act}
              list={list}
              templates={templates}
              onTemplates={async () => setTemplates(await api("/templates"))}
            />
          )}
        </div>
        <footer>
          BidEval · Ellenőrizhető beszerzési döntések{" "}
          <span>Fejlesztői változat · Helyi adattárolás</span>
        </footer>
      </main>
    </div>
  );
}
function Setup({ p, writable, onSave, onFinalize }: Data) {
  const [items, setItems] = useState(p.items),
    [requirements, setReq] = useState(p.requirements),
    [method, setMethod] = useState(p.method),
    [minimum, setMin] = useState(p.minimum),
    [decimalPlaces, setDecimalPlaces] = useState(p.decimalPlaces ?? 3);
  const locked = p.phase !== "setup" || !writable;
  const update = (id: string, key: string, value: string) =>
    setItems(
      items.map((i: Data) => (i.id === id ? { ...i, [key]: value } : i)),
    );
  return (
    <div className="panel form">
      <h2>Értékelési feltételek</h2>
      <p>
        A kiküldés előtt véglegesítse a módszert, mennyiségeket és súlyszámokat.
        A véglegesített feltételek zárolásra kerülnek.
      </p>
      <div className="grid">
        <label>
          Értékelési módszer
          <select
            disabled={locked}
            value={method}
            onChange={(e) => setMethod(e.target.value)}
          >
            {Object.entries(methods).map(([k, v]: any) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </label>
        {method === "points" && (
          <label>
            Minimális pontszám
            <input
              disabled={locked}
              value={minimum}
              onChange={(e) => setMin(e.target.value)}
            />
          </label>
        )}
      </div>
      <label>
        Megjelenített tizedesjegyek (fél felfelé kerekítés)
        <select
          disabled={locked}
          value={decimalPlaces}
          onChange={(e) => setDecimalPlaces(Number(e.target.value))}
        >
          {[0, 1, 2, 3, 4, 5, 6].map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
      </label>
      <p>
        Nulla ár pontozásos módszernél: a bírálat tisztázásig blokkolt. Az
        ár-összehasonlító módszerekben a nulla ár megengedett.
      </p>
      <h3>Ajánlati ártábla</h3>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Tétel</th>
              <th>Mennyiség</th>
              <th>Mértékegység</th>
              <th>Súly / maximális pont</th>
              <th>Tételcsoport</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {items.map((i: Data) => (
              <tr key={i.id}>
                {["name", "quantity", "unit", "weight", "group"].map((k) => (
                  <td key={k}>
                    <input
                      aria-label={k + " " + i.id}
                      disabled={locked}
                      value={i[k] ?? ""}
                      onChange={(e) => update(i.id, k, e.target.value)}
                    />
                  </td>
                ))}
                <td>
                  {!locked && (
                    <button
                      className="icon"
                      onClick={() =>
                        setItems(items.filter((x: Data) => x.id !== i.id))
                      }
                    >
                      ×
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!locked && (
        <button
          className="secondary"
          onClick={() =>
            setItems([
              ...items,
              {
                id: crypto.randomUUID(),
                name: "",
                quantity: "1",
                unit: "db",
                weight: "1",
              },
            ])
          }
        >
          <Plus size={16} /> Új tétel
        </button>
      )}
      <small>
        Tört súlyszám is használható, például 10/3. A rangsorolás pontos
        törtszámokkal, kerekítés nélkül történik.
      </small>
      <h3>Kötelező megfelelőségi követelmények</h3>
      {requirements.map((r: Data) => (
        <div className="inline" key={r.id}>
          <input
            disabled={locked}
            placeholder="Követelmény"
            value={r.name}
            onChange={(e) =>
              setReq(
                requirements.map((x: Data) =>
                  x.id === r.id ? { ...x, name: e.target.value } : x,
                ),
              )
            }
          />
          {!locked && (
            <button
              className="icon"
              onClick={() =>
                setReq(requirements.filter((x: Data) => x.id !== r.id))
              }
            >
              ×
            </button>
          )}
        </div>
      ))}
      {!locked && (
        <button
          className="secondary"
          onClick={() =>
            setReq([...requirements, { id: crypto.randomUUID(), name: "" }])
          }
        >
          <Plus size={16} /> Követelmény hozzáadása
        </button>
      )}
      <div className="actions">
        {!locked ? (
          <>
            <button
              onClick={() =>
                onSave({
                  items,
                  requirements,
                  method,
                  minimum,
                  decimalPlaces,
                  revision: p.revision,
                })
              }
            >
              Feltételek mentése
            </button>
            <button className="secondary" onClick={onFinalize}>
              Mentett feltételek véglegesítése <LockKeyhole size={16} />
            </button>
          </>
        ) : (
          <span className="badge approved">
            Véglegesített módszer · {p.setupVersion?.id}
          </span>
        )}
      </div>
      {p.phase === "setup" && (
        <p className="notice">Véglegesítés előtt mentse a módosításokat.</p>
      )}
      <a
        className="text-button"
        href={"/api/procurements/" + p.id + "/tender.xlsx"}
        download="ajanlati-artabla.xlsx"
      >
        <Download size={16} /> Ajánlati ártábla és módszer (XLSX)
      </a>
      <a
        className="text-button"
        download="ajanlati-artabla.csv"
        href={
          "data:text/csv;charset=utf-8," +
          encodeURIComponent(
            "\uFEFF" +
              [
                "Tételazonosító;Tétel;Mennyiség;Mértékegység;Súly;Nettó egységár",
                ...items.map((i: Data) =>
                  [i.id, i.name, i.quantity, i.unit, i.weight, ""]
                    .map(
                      (v) =>
                        '"' +
                        String(v)
                          .replace(/^[=+@-]/, "'$&")
                          .replaceAll('"', '""') +
                        '"',
                    )
                    .join(";"),
                ),
              ].join("\r\n"),
          )
        }
      >
        <Download size={16} /> Ajánlati ártábla (CSV)
      </a>
      <a
        className="text-button"
        download="ertekelesi-modszer.txt"
        href={
          "data:text/plain;charset=utf-8," +
          encodeURIComponent(
            methods[method] +
              "\n" +
              (method === "points"
                ? "P = Pmin + (Alegjobb / Avizsgált) × (Pmax − Pmin); Pmin=" +
                  minimum
                : method === "weighted"
                  ? "T = SUM(egységár × súlyszám)"
                  : "T = SUM(egységár × mennyiség)") +
              "\n" +
              items
                .map(
                  (i: Data) =>
                    `${i.name}: mennyiség ${i.quantity} ${i.unit}, súly ${i.weight}`,
                )
                .join("\n"),
          )
        }
      >
        <Download size={16} /> Értékelési módszer ismertetése
      </a>
    </div>
  );
}
function Bid({ b, p, writable, onSave, onUpload, onImport }: Data) {
  const [prices, setPrices] = useState(b.versions.at(-1)?.prices || {}),
    [checks, setChecks] = useState(b.checks),
    [status, setStatus] = useState(b.status),
    [compliance, setCompliance] = useState(b.compliance || "pending"),
    [note, setNote] = useState("");
  const locked = p.phase === "setup" || !!p.snapshot || !writable;
  return (
    <div className="panel form">
      <div className="panel-title">
        <h2>{b.name}</h2>
        <span className="badge">{b.versions.length} ajánlatverzió</span>
      </div>
      <label>
        Ajánlat státusza
        <select
          disabled={locked}
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="invited">Felkért, nem érkezett ajánlat</option>
          <option value="submitted">Ajánlatot benyújtott</option>
          <option value="withdrawn">Visszavont ajánlat</option>
        </select>
      </label>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Tétel</th>
              <th>Mennyiség</th>
              <th>Nettó egységár (Ft)</th>
            </tr>
          </thead>
          <tbody>
            {p.items.map((i: Data) => (
              <tr key={i.id}>
                <td>{i.name}</td>
                <td>
                  {i.quantity} {i.unit}
                </td>
                <td>
                  <input
                    disabled={locked}
                    aria-label={b.name + " " + i.name + " ára"}
                    value={prices[i.id] ?? ""}
                    onChange={(e) =>
                      setPrices({ ...prices, [i.id]: e.target.value })
                    }
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!locked && (
        <label>
          Egységárak importálása (XLSX vagy CSV)
          <input
            type="file"
            accept=".xlsx,.csv"
            onChange={async (e) => {
              if (e.target.files?.[0]) {
                const f = new FormData();
                f.set("file", e.target.files[0]);
                const data = await onImport(f);
                if (data) setPrices(data.prices);
                e.target.value = "";
              }
            }}
          />
        </label>
      )}
      <h3>Megfelelőségi vizsgálat</h3>
      <label>
        Összesített bírálói megfelelőségi megállapítás
        <select
          disabled={locked}
          value={compliance}
          onChange={(e) => setCompliance(e.target.value)}
        >
          {["pending", "pass", "fail", "clarify"].map((k) => (
            <option key={k} value={k}>
              {statuses[k]}
            </option>
          ))}
        </select>
      </label>
      {p.requirements.map((r: Data) => (
        <div className="grid requirement" key={r.id}>
          <label>
            {r.name}
            <select
              disabled={locked}
              value={checks[r.id]?.status || "pending"}
              onChange={(e) =>
                setChecks({
                  ...checks,
                  [r.id]: { ...checks[r.id], status: e.target.value },
                })
              }
            >
              {Object.entries(statuses).map(([k, v]: any) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </label>
          <label>
            Indokolás / megjegyzés
            <input
              disabled={locked}
              value={checks[r.id]?.note || ""}
              onChange={(e) =>
                setChecks({
                  ...checks,
                  [r.id]: {
                    status: checks[r.id]?.status || "pending",
                    note: e.target.value,
                  },
                })
              }
            />
          </label>
        </div>
      ))}
      {!p.requirements.length && <p>Nincs előzetesen rögzített követelmény.</p>}
      <label>
        Verzió indoka (eredeti ajánlat, hiánypótlás, ártárgyalás)
        <input
          disabled={locked}
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </label>
      {!locked && (
        <button
          onClick={() =>
            onSave({
              status,
              compliance,
              prices: status === "submitted" ? prices : undefined,
              checks: Object.fromEntries(
                p.requirements.map((r: Data) => [
                  r.id,
                  checks[r.id] || { status: "pending", note: "" },
                ]),
              ),
              note,
            })
          }
        >
          Új ajánlatverzió mentése
        </button>
      )}
      <details>
        <summary>Korábbi ajánlatverziók</summary>
        {b.versions.map((v: Data) => (
          <p key={v.id}>
            {v.created} · {v.note || "Ajánlat"}
            <br />
            {p.items
              .map((i: Data) => `${i.name}: ${v.prices[i.id]} Ft`)
              .join(" · ")}
          </p>
        ))}
      </details>
      {!locked && (
        <label>
          Ajánlati dokumentum feltöltése (PDF, XLSX, DOCX, CSV)
          <input
            type="file"
            accept=".pdf,.xlsx,.docx,.csv"
            onChange={(e) => {
              if (e.target.files?.[0]) {
                const f = new FormData();
                f.set("file", e.target.files[0]);
                onUpload(f);
                e.target.value = "";
              }
            }}
          />
        </label>
      )}
    </div>
  );
}
function Exports({ p, templates, act }: Data) {
  const [t, setT] = useState(""),
    [docs, setDocs] = useState<Data[]>([]);
  useEffect(() => {
    api("/procurements/" + p.id + "/documents").then(setDocs);
  }, [p.id]);
  async function download(url: string, name: string) {
    const r = await fetch("/api" + url);
    if (!r.ok) throw Error((await r.json()).error);
    const u = URL.createObjectURL(await r.blob());
    const a = document.createElement("a");
    a.href = u;
    a.download = name;
    a.click();
    URL.revokeObjectURL(u);
  }
  return (
    <div className="panel form">
      <h2>Bírálati dokumentumok</h2>
      {!p.snapshot ? (
        <p className="notice">
          Az exportokhoz előbb jóvá kell hagyni a döntési javaslatot.
        </p>
      ) : (
        <>
          <p>
            Mindkét export ugyanabból a jóváhagyott pillanatképből készül:{" "}
            {p.snapshot.id}
          </p>
          <button
            onClick={() =>
              act(() =>
                download(
                  "/procurements/" + p.id + "/export.xlsx",
                  "osszehasonlitas.xlsx",
                ),
              )
            }
          >
            <Download size={16} /> Összehasonlító Excel
          </button>
          <h3>Hivatalos bírálati lap</h3>
          {!templates.some((x: Data) => x.approved) ? (
            <p className="notice">
              Az eredeti, jóváhagyott DOCX-sablon hiányzik. A hivatalos lap nem
              állítható elő, és formahűsége nincs igazolva.
            </p>
          ) : (
            <>
              <label>
                Sablonverzió
                <select value={t} onChange={(e) => setT(e.target.value)}>
                  <option value="">Válasszon sablont</option>
                  {templates
                    .filter((x: Data) => x.approved)
                    .map((x: Data) => (
                      <option key={x.id} value={x.id}>
                        {x.name} · {x.created}
                      </option>
                    ))}
                </select>
              </label>
              <button
                disabled={!t}
                onClick={() =>
                  act(() =>
                    download(
                      "/procurements/" + p.id + "/report.docx?template=" + t,
                      "Biralati-lap.docx",
                    ),
                  )
                }
              >
                <Download size={16} /> Bírálati lap (DOCX)
              </button>
              <button
                className="secondary"
                disabled={!t}
                onClick={() =>
                  act(() =>
                    download(
                      "/procurements/" + p.id + "/report.pdf?template=" + t,
                      "Biralati-lap.pdf",
                    ),
                  )
                }
              >
                <Download size={16} /> PDF-előnézet
              </button>
            </>
          )}
        </>
      )}
      <h3>Privát ajánlati dokumentumok</h3>
      {docs.map((d) => (
        <button
          className="text-button"
          key={d.id}
          onClick={() => act(() => download("/documents/" + d.id, d.name))}
        >
          <FileText size={16} />
          {d.name}
        </button>
      ))}
      {!docs.length && <p>Nincs feltöltött dokumentum.</p>}
    </div>
  );
}
const actionLabels: Data = {
  created: "Ügy létrehozva",
  setup_updated: "Feltételek módosítva",
  setup_finalized: "Értékelési feltételek véglegesítve",
  bidder_added: "Partner felvéve",
  bid_revision: "Ajánlatverzió rögzítve",
  decision_approved: "Döntési javaslat jóváhagyva",
  document_added: "Dokumentum feltöltve",
  report_generated: "Bírálati lap elkészítve",
  xlsx_generated: "Összehasonlító Excel elkészítve",
  membership_granted: "Ügyhozzáférés megadva",
  membership_revoked: "Ügyhozzáférés visszavonva",
};
function History({ id }: Data) {
  const [rows, setRows] = useState<Data[]>([]);
  useEffect(() => {
    api("/procurements/" + id + "/audit").then(setRows);
  }, [id]);
  return (
    <div className="panel form">
      <h2>Bírálati előzmények</h2>
      {rows.map((r, i) => (
        <details key={i}>
          <summary>
            {new Date(r.created).toLocaleString("hu-HU")} ·{" "}
            {actionLabels[r.action] || r.action}
          </summary>
          <pre>{JSON.stringify(JSON.parse(r.data), null, 2)}</pre>
        </details>
      ))}
    </div>
  );
}
function Admin({ act, list, onTemplates, templates }: Data) {
  const [users, setUsers] = useState<Data[]>([]);
  const load = () => api("/users").then(setUsers);
  useEffect(() => {
    load();
  }, []);
  return (
    <>
      <h1>Adminisztráció</h1>
      {templates
        .filter((t: Data) => !t.approved)
        .map((t: Data) => (
          <form
            key={t.id}
            className="panel form"
            onSubmit={(e) => {
              e.preventDefault();
              act(async () => {
                await api("/templates/" + t.id + "/approve", {
                  confirmed: true,
                });
                await onTemplates();
              });
            }}
          >
            <h2>Előkészített eredeti sablon</h2>
            <p>
              {t.name}. Az eredeti logó, fejléc és stílus megőrzött; a
              szabályzat aktuális hatályosságát a feltöltés önmagában nem
              igazolja.
            </p>
            <a
              href={"/api/templates/" + t.id}
              download="elokeszitett-sablon.docx"
            >
              Sablon letöltése ellenőrzéshez
            </a>
            <label className="checkbox">
              <input type="checkbox" required /> Ellenőriztem és jóváhagyom a
              sablon formai megfelelőségét és aktuális hatályosságát.
            </label>
            <button>Sablon jóváhagyása</button>
          </form>
        ))}
      <form
        className="panel form"
        onSubmit={(e) => {
          e.preventDefault();
          const f = Object.fromEntries(new FormData(e.currentTarget));
          act(async () => {
            await api("/users", f);
            await load();
          });
        }}
      >
        <h2>Meghívásos felhasználó létrehozása</h2>
        <p>
          E-mail-küldés még nincs bekötve. A kezdeti jelszót biztonságos
          csatornán adja át.
        </p>
        <div className="grid">
          <label>
            E-mail
            <input name="email" type="email" required />
          </label>
          <label>
            Kezdeti jelszó
            <input name="password" type="password" minLength={12} required />
          </label>
          <label>
            Szerepkör
            <select name="role">
              <option value="reviewer">Bíráló</option>
              <option value="viewer">Megtekintő</option>
              <option value="admin">Adminisztrátor</option>
            </select>
          </label>
        </div>
        <button>Felhasználó létrehozása</button>
        {users.map((u) => (
          <div className="inline" key={u.id}>
            <span>
              {u.email} · {u.role} · {u.active ? "Aktív" : "Visszavont"}
            </span>
            {!!u.active && (
              <button
                type="button"
                className="secondary"
                onClick={() =>
                  act(async () => {
                    await api("/users/" + u.id + "/revoke", {});
                    await load();
                  })
                }
              >
                Hozzáférés visszavonása
              </button>
            )}
          </div>
        ))}
      </form>
      <form
        className="panel form"
        onSubmit={(e) => {
          e.preventDefault();
          const f = Object.fromEntries(new FormData(e.currentTarget));
          act(() =>
            f.action === "revoke"
              ? api(
                  "/procurements/" + f.procurement + "/members/" + f.userId,
                  undefined,
                  "DELETE",
                )
              : api("/procurements/" + f.procurement + "/members", {
                  userId: f.userId,
                }),
          );
        }}
      >
        <h2>Ügyhozzáférés megadása</h2>
        <label>
          Beszerzés
          <select name="procurement">
            {list.map((p: Data) => (
              <option key={p.id} value={p.id}>
                {p.title}
              </option>
            ))}
          </select>
        </label>
        <label>
          Felhasználó
          <select name="userId">
            {users
              .filter((u) => u.active)
              .map((u) => (
                <option key={u.id} value={u.id}>
                  {u.email}
                </option>
              ))}
          </select>
        </label>
        <label>
          Művelet
          <select name="action">
            <option value="grant">Hozzáférés megadása</option>
            <option value="revoke">Ügyhozzáférés visszavonása</option>
          </select>
        </label>
        <button>Hozzáférés módosítása</button>
      </form>
      <form
        className="panel form"
        onSubmit={(e) => {
          e.preventDefault();
          const f = Object.fromEntries(new FormData(e.currentTarget));
          act(() =>
            api("/users/" + f.userId + "/reset-password", {
              password: f.password,
            }),
          );
        }}
      >
        <h2>Jelszó visszaállítása</h2>
        <p>
          A felhasználó meglévő munkamenetei megszűnnek. Az új jelszót
          biztonságos csatornán adja át.
        </p>
        <label>
          Felhasználó
          <select name="userId">
            {users
              .filter((u) => u.active)
              .map((u) => (
                <option key={u.id} value={u.id}>
                  {u.email}
                </option>
              ))}
          </select>
        </label>
        <label>
          Új jelszó
          <input name="password" type="password" minLength={12} required />
        </label>
        <button>Jelszó visszaállítása</button>
      </form>
      <form
        className="panel form"
        onSubmit={(e) => {
          e.preventDefault();
          const f = new FormData(e.currentTarget);
          act(async () => {
            await api("/templates", f);
            await onTemplates();
          });
        }}
      >
        <h2>Hivatalos DOCX-sablon feltöltése</h2>
        <p>
          Az eredeti Word-fájl jóváhagyott másolatába helyezze el a dokumentált
          sablonmezőket. A fejlécet, logót és formázást őrizze meg.
        </p>
        <input type="file" name="file" accept=".docx" required />
        <label className="checkbox">
          <input type="checkbox" name="confirmed" value="true" required /> A
          sablon jóváhagyott, korábbi ügyadatoktól és aláírásképektől
          megtisztított.
        </label>
        <button>Sablonverzió mentése</button>
      </form>
    </>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
