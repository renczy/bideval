# Ellenőrzési bizonyíték

A tesztek elkülönített adatbázisokat és fiktív ajánlatokat használnak. Az ellenőrzött helyi környezet Node 24, Chromium és LibreOfficeDev 26.8.0 alpha.

- `npm test`: 32 sikeres teszt; pontos számítás, import/export, hitelesítés, ügyjogosultság, zárolás, verziók, döntés és archiválás.
- `npm run build`: TypeScript és frontend build sikeres.
- `npm run test:e2e`: 3 sikeres böngészős folyamat; teljes bírálat, mobilnézet, valódi előkészített DOCX és PDF letöltése. Az eredeti sablonos teszt csak privát sablon hiányakor kihagyott; ebben a környezetben lefutott.
- `npm run documents:validate`: négy szempontos és húsztételes eset, négy fiktív ajánlattevővel. DOCX, PDF és XLSX ugyanabból a fiktív pillanatképből; folytatóoldalak ellenőrzése.
- `npm audit`: 0 jelentett sérülékenység a vizsgált függőségeknél.

A dokumentumvizsgálat byte-szinten ellenőrzi a fejléc/stílus/betű/theme/logó védett részeit és az eredeti táblázatok tulajdonságait. A renderelt fejléc és cím kijelölt területeit pixel-szinten hasonlítja az eredetihez; a változó oldalszámot külön ellenőrzi. Vizsgálja a pontszámokat, neveket, feloldatlan mezőket, szöveg lapra illeszkedését és a példa korábbi adatainak/képeinek kizárását. A teljes lapképek és `checks.json` privát `.data/validation` kimenetek.

Ez helyi regressziós bizonyíték, nem szabályozói tanúsítás. Microsoft Word, stabil éles PDF-renderer, vállalati hatályosság, nagy terhelés és friss felhőfeladatból való visszaállítás nincs igazolva. A Supabase-migráció nem futott éles projekten.
