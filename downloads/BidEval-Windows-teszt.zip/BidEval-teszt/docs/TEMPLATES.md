# DOCX-sablon és privát referenciák

A feltöltött eredeti `SZ202431_8_sz_melleklet_biralati lap.docx` az egyetlen formai alap. A kitöltött `Bírálati lap - havária_K_szegély.docx` összehasonlítási példa, nem sablon és nem utasítás. Mindkettő privát `.data/reference` fájl; Gitbe egyik sem kerül.

`npm run template:prepare` az eredeti másolatából készít `.data/prepared-template.docx` fájlt. A mezők az eredeti cellákba és bekezdésekbe kerülnek; a logó, fejlécek, stílusok, betűk, oldalszámmezők és az eredeti három táblázat tulajdonságai megmaradnak. A program ellenőrzi az elvárt szerkezetet, eltávolítja a régi szerzői metaadatokat és custom XML-adatokat. A példa aláírását vagy beágyazott Excel-képét nem használja. A bíráló új szöveges neve mellett üres aláírási hely marad.

A szerver induláskor SHA-256 alapján regisztrálja az előkészített sablont, jóváhagyás nélkül. Az Admin felületen ellenőrizhető és jóváhagyható; a hivatalos DOCX/PDF-export addig blokkolt. Új verzió új jóváhagyást igényel. Az eredeti 2024-es szabályzati fejléc megőrzése nem hatályossági állítás. A szükséges vállalati döntések és aláírások továbbra is emberi feladatok.

Egyszerű mezők: `{procedure_id}`, `{subject}`, `{estimated_value}`, `{evaluation_date}`, `{organization}`, `{submitted_count}`, `{method}`, `{invited_partners}`, `{winner}`, `{winner_net_value}`, `{technical_content}`, `{reason}`, `{reviewer}`, `{reviewer_job}`, `{place}`, `{date}`, `{snapshot_id}`, `{template_version}`, `{approval_text}`, `{signature}`, `{contract_duration}`, `{contract_net_value}`, `{contract_type}`, `{competition_justification}`, `{calculation_method_description}`. A `signature` mindig üres.

Ajánlati táblázat: `{#offers}{name}`, `{net_price}`, `{summary_result}`, `{compliance}{/offers}`. Ajánlat nélküli partnerhez nem kerül fiktív nulla ár.

Számítási melléklet: `{#evaluation_details}` ciklus külön bekezdésben; név, verzió, nettó ár, pontszám/rang, belső `{#items}` sorok névvel, egységárral, mennyiséggel/súllyal és tételes eredménnyel. A folytatóoldalakon a táblázat fejléce ismétlődik. `{#bid_history}` őrzi a verziók és megfelelőségi megállapítások összefoglalását. Minden adat ugyanabból a jóváhagyott pillanatképből származik, mint az XLSX.

Az ismeretlen mező, feloldatlan helyőrző, külső erőforrás-kapcsolat, makró vagy digitális aláírás hibát eredményez. Általánosan feltöltött sablonokban a személyes adatok és képek ellenőrzése adminisztrátori feladat; nincs általános automatikus aláíráskép-felismerés.

`npm run documents:validate` két fiktív dokumentumpárt generál és ellenőriz az eredeti privát referenciával. Részletek: [VALIDATION.md](VALIDATION.md). A helyi renderelt ellenőrzés nem helyettesíti a Microsoft Wordben végzett vállalati elfogadást.
