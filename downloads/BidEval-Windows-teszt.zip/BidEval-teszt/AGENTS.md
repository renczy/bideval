# BidEval fejlesztési szabályok

- A felület magyar nyelvű. Valódi vállalati ajánlat, személyes adat és aláírás nem kerülhet Gitbe vagy tesztadatba.
- Az eredeti céges DOCX az egyetlen hivatalos formai referencia. Ne generálj hasonló helyettesítő formanyomtatványt. Logó, fejléc, táblázatstílus, betűk, oldalszámozás és aláírási hely megőrzendő. Aláírásképet soha ne másolj új dokumentumba.
- A hivatalos dokumentum formahűsége az eredeti sablon és renderelt vizuális összehasonlítás nélkül nem tekinthető igazoltnak.
- Pontos törtszámokkal számolj. Kerekítés csak megjelenítéskor; ne használd a megjelenített pontszámot rangsorolásra. A súlyozott összehasonlító érték nem szerződéses ár.
- A véglegesített feltételek és képletek az ajánlatok ismeretében nem módosíthatók. Eredeti ajánlatverzió, audit és jóváhagyott pillanatkép nem írható felül.
- A megfelelőség és a nyertesre tett javaslat külön, dokumentált emberi döntés. Nulla áras pontozás tisztázás nélkül blokkolandó.
- A DOCX és XLSX ugyanazon jóváhagyott pillanatkép adatait használja.
- Minden API-nál ellenőrizd a szerepkört és az ügyhozzáférést. Privát dokumentum soha nem statikus publikus fájl.
- Jelszó, bootstrap token, cookie vagy szolgáltatási kulcs nem naplózható és nem commitolható.
- Változtatás után futtasd az érintett teszteket: `npm test`, `npm run build`, felületi folyamatnál `npm run test:e2e`.
- A jelenleg működő helyi SQLite/Node módot ne állítsd Supabase-integrációnak vagy éles üzemre kész rendszernek. A felhős adapter külön hátralévő munka.
- Használd a meglévő checkoutot; ne hozz létre Git worktree-t külön kérés nélkül.
- Éles publikáláshoz, fizetős szolgáltatás aktiválásához és bizalmas adatok külső továbbításához külön jóváhagyás szükséges.
