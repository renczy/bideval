import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { number, methods } from "./evaluation.js";
const states = {
  pending: "Még nem vizsgált",
  pass: "Megfelel",
  fail: "Nem felel meg",
  clarify: "Tisztázandó",
  na: "Nem alkalmazható",
  submitted: "Benyújtott ajánlat",
  invited: "Nem nyújtott be ajánlatot",
  withdrawn: "Visszavont ajánlat",
};
export function validateTemplate(file) {
  const zip = new PizZip(Buffer.from(file));
  const entries = Object.values(zip.files).filter((e) => !e.dir);
  if (
    entries.length > 5000 ||
    entries.reduce((n, e) => n + (e._data?.uncompressedSize || 0), 0) >
      100 * 1024 * 1024
  )
    throw Error("Túl nagy kibontott sablon");
  for (const e of entries)
    if (
      e.name.endsWith(".rels") &&
      /TargetMode=["']External["']/.test(e.asText())
    )
      throw Error("Külső erőforráshoz kapcsolt sablon nem használható");
  if (entries.some((e) => /vbaProject|_xmlsignatures/i.test(e.name)))
    throw Error("Makró vagy korábbi digitális aláírás nem másolható");
  const doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true });
  const text = doc.getFullText();
  for (const field of [
    "procedure_id",
    "subject",
    "estimated_value",
    "evaluation_date",
    "organization",
    "submitted_count",
    "method",
    "winner",
    "winner_net_value",
    "technical_content",
    "reason",
    "reviewer",
    "reviewer_job",
    "place",
    "date",
    "snapshot_id",
    "template_version",
    "#offers",
    "#evaluation_details",
  ])
    if (!text.includes("{" + field + "}"))
      throw Error("Hiányzó kötelező sablonmező: " + field);
  return doc;
}
export function reportData(snapshot, templateId) {
  if (
    !snapshot.decision.contractDuration ||
    !snapshot.decision.contractType ||
    snapshot.decision.contractValue === undefined
  )
    throw Error("A döntési pillanatkép nem tartalmazza a szerződés adatait");
  const s = snapshot,
    source = s.procurement,
    w = s.evaluation.rows.find((r) => r.id === s.decision.winner),
    places = source.decimalPlaces ?? 3;
  const format = (v) => number(v).fixed(places).replace(".", ",");
  const eligible = s.evaluation.ranked.length;
  return {
    procedure_id: source.reference,
    subject: source.title,
    estimated_value: format(source.estimate) + " Ft",
    evaluation_date: s.decision.evaluationDate.replaceAll("-", ".") + ".",
    organization: source.organization,
    submitted_count: source.bidders.filter((b) => b.versions.length).length,
    method: methods[source.method],
    invited_partners: source.bidders.map((b) => b.name).join(", "),
    winner: w.name,
    winner_net_value: format(w.total),
    technical_content: s.decision.technical,
    reason: s.decision.calculationReason + " " + s.decision.reason,
    reviewer: s.decision.reviewer,
    reviewer_job: s.decision.job,
    place: s.decision.place,
    date: s.approved.slice(0, 10).replaceAll("-", ".") + ".",
    snapshot_id: s.id,
    template_version: templateId,
    contract_duration: s.decision.contractDuration,
    contract_net_value: format(s.decision.contractValue),
    contract_type:
      s.decision.contractType === "framework"
        ? "keretszerződést"
        : "egyedi szerződést",
    compliance_summary: `A felkért ${source.bidders.length} partner közül ${source.bidders.filter((b) => b.versions.length).length} nyújtott be ajánlatot. A dokumentált megfelelőségi vizsgálat alapján ${eligible} ajánlat matematikailag értékelhető. A benyújtás és a megfelelőség megállapításai a fenti táblázatban szerepelnek.`,
    invalidity_reasons:
      s.evaluation.rows
        .filter((r) => r.reason)
        .map((r) => `${r.name}: ${r.reason}.`)
        .join("\n") || "Minden értékelt ajánlat megfelelősége igazolt.",
    competition_justification:
      eligible < 3
        ? "Háromnál kevesebb értékelhető ajánlat: " +
          (s.decision.competitionJustification ||
            "Külön bírálói indokolás szükséges.")
        : "",
    offers: s.evaluation.rows.map((r) => ({
      name: r.name,
      net_price:
        r.total !== undefined ? format(r.total) : "Nincs értékelhető ár",
      summary_result:
        r.value !== undefined
          ? (source.method === "points"
              ? "Pontszám: "
              : "Összehasonlító érték: ") +
            format(r.value) +
            "; rang: " +
            r.rank
          : "Nem rangsorolt",
      score: r.value !== undefined ? format(r.value) : "",
      rank: r.rank || "",
      compliance: r.reason || "Megfelel",
    })),
    signature: "",
    criteria: source.items.map((i) => ({ ...i, group: i.group || "" })),
    calculation_method_description:
      methods[source.method] +
      ". " +
      (source.method === "points"
        ? `P = Pmin + (Alegjobb / Avizsgált) × (Pmax − Pmin); Pmin = ${source.minimum}. Az összpontszám a tételes pontszámok összege; a legmagasabb érték kedvezőbb.`
        : source.method === "weighted"
          ? "T = SUM(egységár × súlyszám); a legalacsonyabb érték kedvezőbb. A súlyozott érték nem szerződéses ár."
          : "T = SUM(egységár × mennyiség); a legalacsonyabb érték kedvezőbb.") +
      ` A rangsor pontos törtszámokkal készült; a megjelenítés ${places} tizedesjegyre, fél felfelé kerekít. Nulla ár pontozásnál tisztázást igényel.`,
    evaluation_details: s.evaluation.ranked.map((r) => ({
      name: r.name,
      version: r.version,
      net_price: format(r.total),
      score: format(r.value),
      rank: r.rank,
      items: r.details.map((d) => {
        const i = source.items.find((i) => i.id === d.itemId);
        return {
          name: (i.group ? i.group + " / " : "") + i.name,
          price: format(d.price),
          score: format(d.score),
          coefficient: i.quantity + " " + i.unit + "; súly: " + i.weight,
        };
      }),
    })),
    bid_history: source.bidders.map((b) => ({
      name: b.name,
      version_summary: b.versions.length
        ? b.versions
            .map(
              (v) =>
                `${v.id} (${v.created.slice(0, 10)}; ${v.note || "Ajánlat"}): ` +
                source.items
                  .map((i) => `${i.name}: ${format(v.prices[i.id])} Ft`)
                  .join("; "),
            )
            .join("\n")
        : "Nem nyújtott be ajánlatot",
      compliance_summary:
        states[b.compliance] +
        ". " +
        source.requirements
          .map(
            (r) =>
              `${r.name}: ${states[b.checks[r.id]?.status || "pending"]}; ${b.checks[r.id]?.note || ""}`,
          )
          .join("; "),
    })),
    approval_text:
      "Bírálói döntési javaslat. A szükséges vállalati jóváhagyásokat nem helyettesíti. A dokumentum nincs aláírva.",
  };
}
export function generateReport(snapshot, template) {
  const doc = validateTemplate(template.file);
  doc.render(reportData(snapshot, template.id));
  if (/\{(?:#|\/)?[A-Za-z_][\w.]*\}/.test(doc.getFullText()))
    throw Error("Feloldatlan mező maradt a dokumentumban");
  const zip = doc.getZip();
  const core = zip.file("docProps/core.xml");
  if (core) {
    let xml = core.asText();
    const now = new Date().toISOString();
    xml = xml
      .replace(
        /(<dcterms:(?:created|modified)[^>]*>)[^<]*(<\/dcterms:(?:created|modified)>)/g,
        "$1" + now + "$2",
      )
      .replace(/<cp:lastPrinted[^>]*>[^<]*<\/cp:lastPrinted>/g, "");
    zip.file("docProps/core.xml", xml);
  }
  return zip.generate({ type: "nodebuffer" });
}
