import Decimal from "./rational.js";
export const methods = {
  lowest: "Legalacsonyabb összesített ár",
  weighted: "Súlyozott összehasonlító ár",
  points: "Súlyozott pontozás",
};
export function number(value) {
  if (String(value).length > 240) throw Error("Túl hosszú számérték");
  const parts = String(value).replace(",", ".").split("/");
  if (parts.length > 2) throw Error("Hibás szám");
  const a = new Decimal(parts[0]);
  const n = parts.length === 2 ? a.div(parts[1]) : a;
  if (!n.isFinite()) throw Error("Nem véges szám");
  return n;
}
const validId = (id) =>
  typeof id === "string" &&
  /^[A-Za-z0-9_-]{1,64}$/.test(id) &&
  !["__proto__", "constructor", "prototype"].includes(id);
export function validateSetup(p) {
  if (
    !Number.isInteger(p.decimalPlaces ?? 3) ||
    (p.decimalPlaces ?? 3) < 0 ||
    (p.decimalPlaces ?? 3) > 6
  )
    throw Error("Hibás megjelenítési kerekítés");
  if (!methods[p.method] || !p.items?.length)
    throw Error("Válasszon módszert és legalább egy tételt.");
  if (new Set(p.items.map((i) => i.id)).size !== p.items.length)
    throw Error("Ismétlődő tételazonosító");
  for (const i of p.items) {
    if (
      !validId(i.id) ||
      !i.name ||
      !i.unit ||
      !number(i.quantity).gt(0) ||
      !number(i.weight).gte(0)
    )
      throw Error("Hibás tétel, mennyiség vagy súlyszám");
    if (p.method === "points" && !number(i.weight).gte(number(p.minimum ?? 1)))
      throw Error("A maximális pontszám kisebb a minimálisnál.");
  }
  if (
    !Array.isArray(p.requirements) ||
    p.requirements.some((r) => !validId(r.id) || !r.name?.trim()) ||
    new Set(p.requirements.map((r) => r.id)).size !== p.requirements.length
  )
    throw Error("Hibás megfelelőségi követelmény");
  if (!number(p.minimum ?? 1).gte(0)) throw Error("Hibás minimális pontszám");
}
const exact = (v) => {
  const [n, d] = v.split("/");
  return new Decimal(n, d);
};
export function evaluate(p) {
  validateSetup(p);
  const requirements = p.requirements || [];
  const candidates = (p.bidders || []).map((b) => ({
    ...b,
    current: b.versions?.at(-1),
  }));
  const eligible = candidates.filter(
    (b) =>
      b.status === "submitted" &&
      b.compliance === "pass" &&
      b.current &&
      requirements.every((r) =>
        ["pass", "na"].includes(b.checks?.[r.id]?.status),
      ),
  );
  const valid = eligible.filter((b) =>
    p.items.every((i) => {
      try {
        return number(b.current.prices[i.id]).gte(0);
      } catch {
        return false;
      }
    }),
  );
  const blocked =
    p.method === "points" &&
    valid.some((b) =>
      p.items.some((i) => number(b.current.prices[i.id]).isZero()),
    );
  const rows = candidates.map((b) => {
    let reason = "";
    if (b.status !== "submitted")
      reason =
        b.status === "withdrawn"
          ? "Visszavont ajánlat"
          : "Nem érkezett ajánlat";
    else if (!eligible.includes(b)) reason = "A megfelelőség nem igazolt";
    else if (!valid.includes(b)) reason = "Hiányzó vagy hibás ár";
    else if (blocked) reason = "Nulla ár: bírálói tisztázás szükséges";
    if (reason) {
      let total;
      try {
        if (
          b.current &&
          p.items.every((i) => number(b.current.prices[i.id]).gte(0))
        )
          total = p.items
            .reduce(
              (sum, i) =>
                sum.plus(
                  number(b.current.prices[i.id]).mul(number(i.quantity)),
                ),
              new Decimal(0),
            )
            .toString();
      } catch {}
      return {
        id: b.id,
        name: b.name,
        reason,
        rank: null,
        version: b.current?.id,
        total,
      };
    }
    let total = new Decimal(0),
      value = new Decimal(0);
    const details = p.items.map((i) => {
      const price = number(b.current.prices[i.id]);
      total = total.plus(price.mul(number(i.quantity)));
      let score;
      if (p.method === "points") {
        const best = Decimal.min(
          ...valid.map((x) => number(x.current.prices[i.id])),
        );
        score = number(p.minimum ?? 1).plus(
          best.div(price).mul(number(i.weight).minus(number(p.minimum ?? 1))),
        );
      } else
        score = price.mul(
          number(p.method === "weighted" ? i.weight : i.quantity),
        );
      value = value.plus(score);
      return { itemId: i.id, price: price.toString(), score: score.toString() };
    });
    return {
      id: b.id,
      name: b.name,
      version: b.current.id,
      total: total.toString(),
      value: value.toString(),
      exactValue: value.exact(),
      details,
      rank: 0,
    };
  });
  const ranked = rows
    .filter((r) => !r.reason)
    .sort(
      (a, b) =>
        exact(a.exactValue).cmp(exact(b.exactValue)) *
        (p.method === "points" ? -1 : 1),
    );
  ranked.forEach(
    (r, i) =>
      (r.rank =
        i && exact(r.exactValue).eq(exact(ranked[i - 1].exactValue))
          ? ranked[i - 1].rank
          : i + 1),
  );
  return {
    method: p.method,
    rows,
    ranked,
    needsClarification: blocked,
    tie: ranked.filter((r) => r.rank === 1).length > 1,
  };
}
