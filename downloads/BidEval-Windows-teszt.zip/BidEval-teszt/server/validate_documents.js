// Private reference integration test: no real bidder data, no signature copying.
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { evaluate } from "./evaluation.js";
import { justification, comparisonWorkbook } from "./exports.js";
import { generateReport } from "./report.js";
import { renderPdf } from "./pdf.js";
const dir = path.resolve(process.env.BIDEVAL_DATA_DIR || ".data"),
  out = path.join(dir, "validation");
fs.mkdirSync(out, { recursive: true, mode: 0o700 });
const templateFile = path.join(dir, "prepared-template.docx");
if (!fs.existsSync(templateFile))
  throw Error("Prepare the supplied original private template first");
const p = {
  id: "fiktiv-procurement",
  title: "Fiktív granulátumbeszerzés",
  reference: "FIKTIV-001",
  organization: "Fiktív szervezet",
  estimate: "1500000",
  method: "points",
  minimum: "1",
  decimalPlaces: 3,
  items: ["90", "10/3", "10/3", "10/3"].map((weight, k) => ({
    id: "i" + k,
    name: ["Termék", "Raklap", "Raklap használati díja", "Szállítás"][k],
    quantity: ["10", "1", "1", "1"][k],
    unit: k ? "alkalom" : "zsák",
    weight,
  })),
  requirements: [{ id: "r", name: "Műszaki megfelelőség" }],
  bidders: [],
};
p.bidders = Array.from({ length: 4 }, (_, k) => ({
  id: "b" + k,
  name: ["Fiktív Alfa", "Fiktív Béta", "Fiktív Gamma", "Fiktív Delta"][k],
  status: "submitted",
  compliance: "pass",
  checks: { r: { status: "pass", note: "Fiktív tesztben ellenőrizve" } },
  versions: [
    {
      id: "fiktiv-verzio-" + k,
      created: "2026-10-11T10:00:00Z",
      note: "Eredeti ajánlat",
      prices: Object.fromEntries(
        p.items.map((i) => [i.id, k ? "96000" : "81722"]),
      ),
    },
  ],
}));
const evaluation = evaluate(p),
  snapshot = {
    id: "fiktiv-ellenorzesi-pillanatkep",
    approved: "2026-10-11T10:00:00Z",
    procurement: p,
    evaluation,
    decision: {
      winner: "b0",
      reason:
        "A megfelelő ajánlatok közül a súlyozott pontozás alapján az első helyezett ajánlat javasolt.",
      technical:
        "10 zsák fiktív granulátum, csomagolás és egyszeri kiszállítás.",
      reviewer: "Fiktív Bíráló",
      job: "Beszerző",
      place: "Tesztváros",
      evaluationDate: "2026-10-11",
      contractDuration: "2026. november",
      contractType: "individual",
      contractValue: "1062386",
      calculationReason: justification(p, evaluation, "b0"),
    },
  };
const baseline = path.join(dir, "render", "original.pdf");
fs.mkdirSync(path.dirname(baseline), { recursive: true });
fs.writeFileSync(
  baseline,
  await renderPdf(
    fs.readFileSync(path.join(dir, "reference", "original.docx")),
    dir,
  ),
);
const template = {
  id: "fiktiv-sablon-verzio",
  file: fs.readFileSync(templateFile),
};
for (const [name, source] of [
  ["fiktiv-biralati-lap", snapshot],
  ["fiktiv-nagy-artabla", structuredClone(snapshot)],
]) {
  source.id = "fiktiv-" + randomUUID();
  if (name === "fiktiv-nagy-artabla") {
    source.procurement.items = Array.from({ length: 20 }, (_, k) => ({
      id: "i" + k,
      name: "Fiktív értékelési tétel " + (k + 1),
      quantity: "1",
      unit: "db",
      weight: "5",
      group: k < 10 ? "A csoport" : "B csoport",
    }));
    source.procurement.bidders.forEach((b, k) => {
      b.versions[0].prices = Object.fromEntries(
        source.procurement.items.map((i) => [i.id, String(100 + k * 20)]),
      );
    });
    source.evaluation = evaluate(source.procurement);
    source.decision.contractValue = source.evaluation.ranked[0].total;
    source.decision.calculationReason = justification(
      source.procurement,
      source.evaluation,
      "b0",
    );
    source.decision.technical =
      "Húsz fiktív ártétel összehasonlítása, négy ajánlattevő.";
  }
  const docx = generateReport(source, template);
  fs.writeFileSync(path.join(out, name + ".docx"), docx, { mode: 0o600 });
  fs.writeFileSync(path.join(out, name + ".pdf"), await renderPdf(docx, dir), {
    mode: 0o600,
  });
  fs.writeFileSync(
    path.join(out, name + ".xlsx"),
    await comparisonWorkbook(source),
    { mode: 0o600 },
  );
  fs.writeFileSync(
    path.join(out, name + ".snapshot.json"),
    JSON.stringify(source, null, 2),
    { mode: 0o600 },
  );
}
console.log(
  "Original DOCX template filled and PDF/XLSX rendered with fictional 4-bidder and 20-item cases.",
);
