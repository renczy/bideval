"""Private structural and rendered regressions; logs no completed-example data."""
import argparse, hashlib, json, re, zipfile
from decimal import Decimal,ROUND_HALF_UP
from pathlib import Path
import fitz
from PIL import Image, ImageChops
from lxml import etree as E
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';NS={'w':W};PARSER=E.XMLParser(resolve_entities=False,no_network=True)
def check(root):
    root=Path(root);original=root/'reference/original.docx';baseline=fitz.open(root/'render/original.pdf');results=[]
    with zipfile.ZipFile(original) as source:
        preserved=[n for n in source.namelist() if n.startswith('word/header') or n.startswith('word/media/') or n in ['word/styles.xml','word/fontTable.xml','word/theme/theme1.xml']]
        source_xml=E.fromstring(source.read('word/document.xml'),PARSER);original_tables=source_xml.findall('.//w:body/w:tbl',NS)
        for name in ['fiktiv-biralati-lap','fiktiv-nagy-artabla']:
            folder=root/'validation';snapshot=json.loads((folder/(name+'.snapshot.json')).read_text());pages=fitz.open(folder/(name+'.pdf'));all_text='\n'.join(p.get_text() for p in pages)
            with zipfile.ZipFile(folder/(name+'.docx')) as document:
                assert all(document.read(n)==source.read(n) for n in preserved),'A protected original part changed'
                assert [n for n in document.namelist() if n.startswith('word/media/')]==[n for n in source.namelist() if n.startswith('word/media/')],'Unexpected copied image'
                xml=E.fromstring(document.read('word/document.xml'),PARSER);text=''.join(xml.xpath('.//w:t/text()',namespaces=NS))
                assert not re.search(r'\{[^{}]+\}',text),'Unresolved template field'
                assert not any(x in text for x in ['igen/nem','<Ajánlatkérés tárgya>','AJ-20xx']),'Unresolved original form guidance'
                assert 'Fiktív Bíráló' in text and 'Aláírás helye:' in text
                table=xml.findall('.//w:body/w:tbl',NS)[1]
                for row,result in zip(table.findall('w:tr',NS)[1:],snapshot['evaluation']['rows']):
                    cells=[''.join(c.xpath('.//w:t/text()',namespaces=NS)) for c in row.findall('w:tc',NS)]
                    assert cells[0]==result['name'],'Bidder does not match snapshot'
                    if result.get('total') is not None:
                        expected=str(Decimal(result['total']).quantize(Decimal(1).scaleb(-snapshot['procurement']['decimalPlaces']),rounding=ROUND_HALF_UP)).replace('.',',');assert cells[2]==expected,'Net value does not match snapshot'
                    if result.get('value') is not None:
                        expected=str(Decimal(result['value']).quantize(Decimal(1).scaleb(-snapshot['procurement']['decimalPlaces']),rounding=ROUND_HALF_UP)).replace('.',',');assert expected in cells[1],'Score does not match snapshot'
                with zipfile.ZipFile(root/'reference/completed-example.docx') as completed:
                    completed_root=E.fromstring(completed.read('word/document.xml'),PARSER)
                    filled_tables=completed_root.findall('.//w:body/w:tbl',NS)
                    for row in filled_tables[0].findall('w:tr',NS)[:5]:
                        prior=''.join(row.findall('w:tc',NS)[1].xpath('.//w:t/text()',namespaces=NS)).strip()
                        if len(prior)>4:assert prior not in text,'Previous procurement data copied'
                    source_media={hashlib.sha256(source.read(n)).hexdigest() for n in source.namelist() if n.startswith('word/media/')}
                    private_images={hashlib.sha256(completed.read(n)).hexdigest() for n in completed.namelist() if n.startswith('word/media/')} - source_media
                    assert not any(hashlib.sha256(document.read(n)).hexdigest() in private_images for n in document.namelist() if n.startswith('word/media/')),'Completed example image or signature copied'

                assert not any(n.startswith('customXml/') for n in document.namelist()),'Cached custom document data'
                tables=xml.findall('.//w:body/w:tbl',NS)
                assert len(tables)==3+len(snapshot['evaluation']['ranked'])
                for before,after in zip(original_tables,tables[:3]):
                    for prop in ['w:tblPr','w:tblGrid']:
                        assert E.tostring(before.find(prop,NS))==E.tostring(after.find(prop,NS)),'Original table geometry/style changed'
                for bidder in snapshot['procurement']['bidders']:assert bidder['name'] in all_text
                for item in snapshot['procurement']['items']:assert item['name'] in all_text
            # Identical rendered corporate header, excluding the dynamic page number.
            clip=fitz.Rect(60,25,500,76);a=baseline[0].get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False);b=pages[0].get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False)
            ai=Image.frombytes('RGB',(a.width,a.height),a.samples);bi=Image.frombytes('RGB',(b.width,b.height),b.samples);diff=ImageChops.difference(ai,bi);box=diff.getbbox();assert box is None,'Rendered original corporate header changed'
            title_clip=fitz.Rect(180,110,405,145);a=baseline[0].get_pixmap(matrix=fitz.Matrix(2,2),clip=title_clip,alpha=False);b=pages[0].get_pixmap(matrix=fitz.Matrix(2,2),clip=title_clip,alpha=False);assert a.samples==b.samples,'Original title appearance changed'
            # Confirm every visible text span stays inside the page boundaries.
            for i,page in enumerate(pages):
                assert f'{i+1}/{len(pages)}' in page.get_text().replace(' ',''),'Page numbering not recalculated'
                for block in page.get_text('dict')['blocks']:
                    if 'lines' not in block:continue
                    for line in block['lines']:
                        for span in line['spans']:
                            r=fitz.Rect(span['bbox']);assert r.x0>=-1 and r.y0>=-1 and r.x1<=page.rect.width+1 and r.y1<=page.rect.height+1,'Text extends beyond page'
                page.get_pixmap(matrix=fitz.Matrix(1,1)).save(str(folder/f'{name}-page{i+1}.png'))
            results.append({'case':name,'pages':len(pages),'original_header_pixel_equal':True,'title_pixel_equal':True,'preserved_parts':len(preserved),'visible_text_inside_page':True,'item_count':len(snapshot['procurement']['items']),'bidder_count':len(snapshot['procurement']['bidders'])})
    (root/'validation/checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--data-dir',default='.data');check(parser.parse_args().data_dir)
