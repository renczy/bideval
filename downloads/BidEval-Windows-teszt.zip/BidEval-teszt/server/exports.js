import ExcelJS from "exceljs";
import { number, methods } from "./evaluation.js";
const statusLabels = {
  invited: "Felkért, nem érkezett ajánlat",
  submitted: "Ajánlatot benyújtott",
  withdrawn: "Visszavont ajánlat",
  pending: "Még nem vizsgált",
  pass: "Megfelel",
  fail: "Nem felel meg",
  clarify: "Tisztázandó",
  na: "Nem alkalmazható",
};
export function justification(source, evaluation, winner) {
  const w = evaluation.ranked.find((r) => r.id === winner);
  if (!w) throw Error("Nem értékelhető döntési javaslat");
  const price = evaluation.ranked.reduce((a, b) =>
    number(a.total).cmp(number(b.total)) <= 0 ? a : b,
  );
  return `Az alkalmazott értékelési módszer: ${methods[source.method]}. A nyertesnek javasolt ${w.name} a matematikai rangsor ${w.rank}. helyén áll. ${source.method === "points" ? "Összesített pontszáma" : source.method === "weighted" ? "Súlyozott összehasonlító értéke" : "Összesített összehasonlító nettó ára"}: ${number(w.value).fixed(source.decimalPlaces ?? 3)}. A mennyiségekkel számított nettó ajánlati értéke ${number(w.total).fixed(source.decimalPlaces ?? 3)} Ft. ${source.method === "weighted" ? "A súlyozott összehasonlító érték nem szerződéses ár. " : ""}A legalacsonyabb nettó összértékű értékelhető ajánlatot ${price.name} adta (${number(price.total).fixed(source.decimalPlaces ?? 3)} Ft). A rangsor kizárólag megfelelőnek minősített, teljes áradataikkal értékelhető ajánlatokra vonatkozik. A döntési javaslatot a bíráló rögzítette; ez nem szerződéskötési jóváhagyás.`;
}
export async function comparisonWorkbook(snapshot) {
  const { procurement: p, evaluation: e } = snapshot;
  const wb = new ExcelJS.Workbook();
  wb.calcProperties.fullCalcOnLoad = true;
  const ws = wb.addWorksheet("Összehasonlítás");
  ws.addRow(["BidEval", p.title, snapshot.id]);
  ws.addRow(["Módszer", methods[p.method]]);
  ws.addRow([
    "Tétel",
    "Mennyiség",
    "Egység",
    "Súly",
    ...e.ranked.map((r) => r.name),
  ]);
  p.items.forEach((i) =>
    ws.addRow([
      i.name,
      Number(number(i.quantity).toString()),
      i.unit,
      Number(number(i.weight).toString()),
      ...e.ranked.map((r) =>
        Number(r.details.find((d) => d.itemId === i.id).price),
      ),
    ]),
  );
  const end = 3 + p.items.length,
    lastColumn = ws.getColumn(4 + e.ranked.length).letter;
  const totalRow = ws.addRow([
    "Nettó összeg",
    "",
    "",
    "",
    ...e.ranked.map((r, k) => ({
      formula: `SUMPRODUCT(B4:B${end},${ws.getColumn(5 + k).letter}4:${ws.getColumn(5 + k).letter}${end})`,
      result: Number(r.total),
    })),
  ]).number;
  let scoreStart = 0,
    scoreEnd = 0;
  if (p.method === "points") {
    ws.addRow(["Tételes pontszámok"]);
    scoreStart = ws.rowCount + 1;
    p.items.forEach((i, j) => {
      const row = 4 + j;
      ws.addRow([
        i.name,
        "",
        "",
        "",
        ...e.ranked.map((r, k) => ({
          formula: `${Number(number(p.minimum).toString())}+(MIN(E${row}:${lastColumn}${row})/${ws.getColumn(5 + k).letter}${row})*($D${row}-${Number(number(p.minimum).toString())})`,
          result: Number(r.details.find((d) => d.itemId === i.id).score),
        })),
      ]);
    });
    scoreEnd = ws.rowCount;
  }
  const valueRow = ws.addRow([
    "Értékelési eredmény",
    "",
    "",
    "",
    ...e.ranked.map((r, k) => {
      const c = ws.getColumn(5 + k).letter;
      return {
        formula:
          p.method === "points"
            ? `SUM(${c}${scoreStart}:${c}${scoreEnd})`
            : `SUMPRODUCT(${p.method === "weighted" ? "D" : "B"}4:${p.method === "weighted" ? "D" : "B"}${end},${c}4:${c}${end})`,
        result: Number(r.value),
      };
    }),
  ]).number;
  ws.addRow([
    "Rangsor",
    "",
    "",
    "",
    ...e.ranked.map((r, k) => ({
      formula: `RANK(${ws.getColumn(5 + k).letter}${valueRow},$E$${valueRow}:$${lastColumn}$${valueRow},${p.method === "points" ? 0 : 1})`,
      result: r.rank,
    })),
  ]);
  const meta = wb.addWorksheet("Bírálati adatok");
  meta.addRow(["Pillanatkép", snapshot.id]);
  meta.addRow(["Indokolás", snapshot.decision.reason]);
  meta.addRow([
    "Számítási indokolás",
    snapshot.decision.calculationReason || "",
  ]);
  meta.addRow([
    "Ajánlattevő",
    "Értékelhetőség",
    "Verzió",
    "Nettó ár",
    "Eredmény",
    "Rangsor",
  ]);
  e.rows.forEach((r) =>
    meta.addRow([
      r.name,
      r.reason || "Megfelel",
      r.version || "",
      r.total || "",
      r.value || "",
      r.rank ?? "",
    ]),
  );
  p.bidders.forEach((b) =>
    p.requirements.forEach((r) =>
      meta.addRow([
        b.name,
        r.name,
        statusLabels[b.checks[r.id]?.status] || "Még nem vizsgált",
        b.checks[r.id]?.note,
      ]),
    ),
  );
  const prices = wb.addWorksheet("Ajánlatverziók");
  prices.addRow([
    "Ajánlattevő",
    "Státusz",
    "Összesített megfelelőség",
    "Verzió",
    "Időpont",
    "Verzió indoka",
    "Tétel",
    "Mennyiség",
    "Egység",
    "Súly (pontos)",
    "Nettó egységár",
    "Tételcsoport",
  ]);
  p.bidders.forEach((b) => {
    if (!b.versions.length)
      prices.addRow([
        b.name,
        statusLabels[b.status],
        statusLabels[b.compliance],
        "Nem érkezett ajánlat",
      ]);
    b.versions.forEach((v) =>
      p.items.forEach((i) =>
        prices.addRow([
          b.name,
          statusLabels[b.status],
          statusLabels[b.compliance],
          v.id,
          v.created,
          v.note,
          i.name,
          i.quantity,
          i.unit,
          i.weight,
          v.prices[i.id],
          i.group || "",
        ]),
      ),
    );
  });
  for (const sheet of wb.worksheets) {
    sheet.views = [{ state: "frozen", ySplit: 3, xSplit: 1 }];
    sheet.columns.forEach((c) => (c.width = 27));
    sheet.getRow(3).font = { bold: true };
    sheet.eachRow((row) =>
      row.eachCell((cell) => {
        if (typeof cell.value === "number" || cell.value?.formula)
          cell.numFmt =
            (p.decimalPlaces ?? 3)
              ? "0." + "0".repeat(p.decimalPlaces ?? 3)
              : "0";
        cell.alignment = { vertical: "top", wrapText: true };
      }),
    );
  }
  return Buffer.from(await wb.xlsx.writeBuffer());
}
export async function tenderWorkbook(p) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Ajánlati ártábla");
  ws.addRow([
    "Tételazonosító",
    "Tétel",
    "Mennyiség",
    "Mértékegység",
    "Súly",
    "Nettó egységár",
    "Tételcsoport",
  ]);
  p.items.forEach((i) =>
    ws.addRow([i.id, i.name, i.quantity, i.unit, i.weight, "", i.group || ""]),
  );
  ws.columns.forEach((c) => (c.width = 25));
  ws.getRow(1).font = { bold: true };
  const info = wb.addWorksheet("Értékelési módszer");
  info.addRow(["Beszerzés", p.title]);
  info.addRow(["Eljárás", p.reference]);
  info.addRow(["Módszer", methods[p.method]]);
  info.addRow(["Verzió", p.setupVersion?.id || "NEM VÉGLEGES"]);
  info.addRow([
    "Képlet",
    p.method === "points"
      ? "P = Pmin + (Alegjobb / Avizsgált) × (Pmax − Pmin)"
      : p.method === "weighted"
        ? "T = SUM(egységár × súlyszám)"
        : "T = SUM(egységár × mennyiség)",
  ]);
  info.addRow(["Minimális pont", p.minimum]);
  info.addRow(["Megjelenítési tizedesjegyek", p.decimalPlaces ?? 3]);
  info.addRow([
    "Nulla ár szabálya",
    "Pontozásnál tisztázásig blokkolt; ár-összehasonlításnál megengedett",
  ]);
  p.requirements.forEach((r) => info.addRow(["Követelmény", r.name]));
  return Buffer.from(await wb.xlsx.writeBuffer());
}
