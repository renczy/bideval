import { DatabaseSync } from "node:sqlite";
import readline from "node:readline/promises";
import { stdin, stdout } from "node:process";
import { randomBytes, randomUUID, scryptSync } from "node:crypto";
import path from "node:path";
const db = new DatabaseSync(
  path.resolve(process.env.BIDEVAL_DATA_DIR || ".data", "bideval.sqlite"),
);
const count = db.prepare("SELECT count(*) n FROM users").get().n;
if (count)
  throw Error("Az első admin már létezik. Használja a felhasználókezelést.");
const rl = readline.createInterface({ input: stdin, output: stdout });
const email = await rl.question("Admin e-mail: ");
rl.close();
if (!stdin.isTTY)
  throw Error("Interaktív terminál szükséges a jelszó védett megadásához.");
stdout.write("Jelszó (legalább 12 karakter; rejtett): ");
stdin.setRawMode(true);
let password = "";
await new Promise((resolve) => {
  stdin.on("data", function listener(chunk) {
    const s = chunk.toString();
    for (const c of s) {
      if (c === "\u0003") {
        stdin.setRawMode(false);
        process.exit(1);
      }
      if (c === "\r" || c === "\n") {
        stdin.removeListener("data", listener);
        resolve();
        return;
      }
      if (c === "\u007f") password = password.slice(0, -1);
      else password += c;
    }
  });
});
stdin.setRawMode(false);
stdin.pause();
stdout.write("\n");
if (!email.includes("@") || password.length < 12)
  throw Error("Hibás e-mail vagy rövid jelszó");
const salt = randomBytes(16).toString("hex");
db.prepare("INSERT INTO users(id,email,hash,role) VALUES(?,?,?,?)").run(
  randomUUID(),
  email.toLowerCase(),
  salt + ":" + scryptSync(password, salt, 64).toString("hex"),
  "admin",
);
db.close();
console.log("Adminisztrátor létrehozva.");
