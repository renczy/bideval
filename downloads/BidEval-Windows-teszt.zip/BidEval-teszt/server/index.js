import {
  comparisonWorkbook,
  tenderWorkbook,
  justification,
} from "./exports.js";
import { Readable } from "node:stream";
import { generateReport, validateTemplate } from "./report.js";
import { renderPdf } from "./pdf.js";
import express from "express";
import multer from "multer";
import { DatabaseSync } from "node:sqlite";
import {
  randomBytes,
  scryptSync,
  timingSafeEqual,
  createHash,
  randomUUID,
} from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import ExcelJS from "exceljs";
import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { evaluate, validateSetup, methods, number } from "./evaluation.js";
const dir = path.resolve(process.env.BIDEVAL_DATA_DIR || ".data");
fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
const db = new DatabaseSync(path.join(dir, "bideval.sqlite"));
db.exec(
  `PRAGMA foreign_keys=ON;CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE,hash TEXT,role TEXT,active INTEGER DEFAULT 1);CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),expires INTEGER);CREATE TABLE IF NOT EXISTS procurements(id TEXT PRIMARY KEY,owner TEXT REFERENCES users(id),data TEXT);CREATE TABLE IF NOT EXISTS memberships(procurement_id TEXT REFERENCES procurements(id),user_id TEXT REFERENCES users(id),PRIMARY KEY(procurement_id,user_id));CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,procurement_id TEXT,actor TEXT,action TEXT,data TEXT,created TEXT);CREATE TABLE IF NOT EXISTS templates(id TEXT PRIMARY KEY,name TEXT,file BLOB,created TEXT);CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,procurement_id TEXT REFERENCES procurements(id),bidder_id TEXT,name TEXT,file BLOB,created TEXT);`,
);
db.exec(fs.readFileSync(new URL("./schema.sql", import.meta.url), "utf8"));
if (
  !db
    .prepare("PRAGMA table_info(line_items)")
    .all()
    .some((c) => c.name === "group_name")
)
  db.exec(
    "ALTER TABLE line_items ADD COLUMN group_name TEXT NOT NULL DEFAULT ''",
  );
for (const [name, type] of [
  ["approved", "INTEGER NOT NULL DEFAULT 0"],
  ["approved_by", "TEXT"],
  ["approved_at", "TEXT"],
  ["checksum", "TEXT"],
])
  if (
    !db
      .prepare("PRAGMA table_info(templates)")
      .all()
      .some((c) => c.name === name)
  )
    db.exec("ALTER TABLE templates ADD COLUMN " + name + " " + type);
const preparedFile = path.join(dir, "prepared-template.docx");
if (fs.existsSync(preparedFile)) {
  const file = fs.readFileSync(preparedFile),
    checksum = createHash("sha256").update(file).digest("hex");
  if (!db.prepare("SELECT id FROM templates WHERE checksum=?").get(checksum))
    db.prepare(
      "INSERT INTO templates(id,name,file,created,approved,checksum) VALUES(?,?,?,?,0,?)",
    ).run(
      randomUUID(),
      "SZ/2024/31 – előkészített bírálati lap",
      file,
      new Date().toISOString(),
      checksum,
    );
}
const hash = (p) => {
  const salt = randomBytes(16).toString("hex");
  return salt + ":" + scryptSync(p, salt, 64).toString("hex");
};
const verify = (p, h) => {
  const [s, v] = h.split(":");
  return timingSafeEqual(scryptSync(p, s, 64), Buffer.from(v, "hex"));
};
const tokenHash = (t) => createHash("sha256").update(t).digest("hex");
const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "2mb" }));
app.use((req, res, next) => {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "same-origin",
    "Cache-Control": "no-store",
  });
  if (
    !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
    req.headers.origin &&
    new URL(req.headers.origin).host !== req.headers.host &&
    !(
      process.env.BIDEVAL_FRONTEND_ORIGIN ||
      "http://127.0.0.1:5173,http://localhost:5173"
    )
      .split(",")
      .includes(req.headers.origin)
  )
    return res.status(403).json({ error: "Idegen eredetű kérés" });
  next();
});
const attempts = new Map();
function limited(req) {
  const k = req.ip;
  const t = attempts.get(k) || { count: 0, start: Date.now() };
  if (Date.now() - t.start > 900000) {
    t.count = 0;
    t.start = Date.now();
  }
  t.count++;
  attempts.set(k, t);
  if (t.count > 30) throw Error("Túl sok próbálkozás; várjon 15 percet.");
}
app.get("/api/status", (req, res) =>
  res.json({
    bootstrap: db.prepare("SELECT count(*) n FROM users").get().n === 0,
  }),
);
app.post("/api/bootstrap", (req, res, next) => {
  try {
    limited(req);
    if (db.prepare("SELECT count(*) n FROM users").get().n)
      throw Error("Az adminisztrátor már létrejött");
    if (
      !process.env.BIDEVAL_BOOTSTRAP_TOKEN ||
      req.body.token !== process.env.BIDEVAL_BOOTSTRAP_TOKEN
    )
      throw Error("Érvénytelen telepítési token");
    const { email, password } = req.body;
    if (!email?.includes("@") || password?.length < 12)
      throw Error("Érvényes e-mail és legalább 12 karakteres jelszó szükséges");
    db.prepare("INSERT INTO users(id,email,hash,role) VALUES(?,?,?,?)").run(
      randomUUID(),
      email.toLowerCase(),
      hash(password),
      "admin",
    );
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});
app.post("/api/login", (req, res, next) => {
  try {
    limited(req);
    const u = db
      .prepare("SELECT * FROM users WHERE email=? AND active=1")
      .get(String(req.body.email).toLowerCase());
    if (!u || !verify(String(req.body.password), u.hash))
      throw Error("Hibás belépési adatok");
    const t = randomBytes(32).toString("hex");
    db.prepare("INSERT INTO sessions VALUES(?,?,?)").run(
      tokenHash(t),
      u.id,
      Date.now() + 8 * 3600000,
    );
    res
      .cookie("session", t, {
        httpOnly: true,
        sameSite: "strict",
        secure: process.env.BIDEVAL_HTTPS === "1",
        maxAge: 8 * 3600000,
        path: "/",
      })
      .json({ id: u.id, email: u.email, role: u.role });
  } catch (e) {
    next(e);
  }
});
app.use("/api", (req, res, next) => {
  const t = req.headers.cookie
    ?.split(";")
    .map((x) => x.trim())
    .find((x) => x.startsWith("session="))
    ?.slice(8);
  req.user =
    t &&
    db
      .prepare(
        "SELECT u.id,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>? AND u.active=1",
      )
      .get(tokenHash(t), Date.now());
  if (!req.user)
    return res.status(401).json({ error: "Bejelentkezés szükséges" });
  next();
});
app.get("/api/me", (req, res) => res.json(req.user));
app.post("/api/logout", (req, res) => {
  const t = req.headers.cookie?.match(/session=([^;]+)/)?.[1];
  if (t) db.prepare("DELETE FROM sessions WHERE token=?").run(tokenHash(t));
  res.clearCookie("session").json({ ok: true });
});
function access(id, u, write = false) {
  const row = db.prepare("SELECT * FROM procurements WHERE id=?").get(id);
  if (!row) throw Error("Az ügy nem található");
  if (
    u.role !== "admin" &&
    row.owner !== u.id &&
    !db
      .prepare("SELECT 1 FROM memberships WHERE procurement_id=? AND user_id=?")
      .get(id, u.id)
  )
    throw Error("Nincs jogosultság");
  if (write && u.role === "viewer") throw Error("Csak olvasási jogosultság");
  return JSON.parse(row.data);
}
function audit(id, u, action, data) {
  db.prepare(
    "INSERT INTO audit(procurement_id,actor,action,data,created) VALUES(?,?,?,?,?)",
  ).run(id, u.id, action, JSON.stringify(data), new Date().toISOString());
}
function save(p) {
  db.prepare("UPDATE procurements SET data=? WHERE id=?").run(
    JSON.stringify(p),
    p.id,
  );
  for (const i of p.items) {
    const existing = db
      .prepare("SELECT procurement_id FROM line_items WHERE id=?")
      .get(i.id);
    if (existing && existing.procurement_id !== p.id)
      throw Error("Másik ügy tételazonosítója");
    db.prepare(
      "INSERT INTO line_items(id,procurement_id,name,quantity,unit,weight,group_name) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,quantity=excluded.quantity,unit=excluded.unit,weight=excluded.weight,group_name=excluded.group_name",
    ).run(
      i.id,
      p.id,
      i.name,
      String(i.quantity),
      i.unit,
      String(i.weight),
      i.group || "",
    );
  }
  for (const r of p.requirements) {
    const existing = db
      .prepare("SELECT procurement_id FROM requirements WHERE id=?")
      .get(r.id);
    if (existing && existing.procurement_id !== p.id)
      throw Error("Másik ügy követelményazonosítója");
    db.prepare(
      "INSERT INTO requirements VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name",
    ).run(r.id, p.id, r.name);
  }
  if (p.phase === "setup") {
    for (const r of db
      .prepare("SELECT id FROM line_items WHERE procurement_id=?")
      .all(p.id))
      if (!p.items.some((i) => i.id === r.id))
        db.prepare("DELETE FROM line_items WHERE id=?").run(r.id);
    for (const r of db
      .prepare("SELECT id FROM requirements WHERE procurement_id=?")
      .all(p.id))
      if (!p.requirements.some((i) => i.id === r.id))
        db.prepare("DELETE FROM requirements WHERE id=?").run(r.id);
  }
  for (const b of p.bidders) {
    db.prepare(
      "INSERT INTO bidders VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,compliance=excluded.compliance",
    ).run(b.id, p.id, b.name, b.status, b.compliance);
    for (const v of b.versions) {
      db.prepare("INSERT OR IGNORE INTO bid_versions VALUES(?,?,?,?)").run(
        v.id,
        b.id,
        v.note,
        v.created,
      );
      for (const i of p.items)
        db.prepare("INSERT OR IGNORE INTO bid_prices VALUES(?,?,?)").run(
          v.id,
          i.id,
          String(v.prices[i.id]),
        );
    }
    for (const r of p.requirements) {
      const c = b.checks[r.id];
      if (c)
        db.prepare(
          "INSERT INTO compliance_checks VALUES(?,?,?,?) ON CONFLICT(bidder_id,requirement_id) DO UPDATE SET status=excluded.status,note=excluded.note",
        ).run(b.id, r.id, c.status, c.note || "");
    }
  }
  if (p.setupVersion)
    db.prepare("INSERT OR IGNORE INTO evaluation_setups VALUES(?,?,?,?)").run(
      p.setupVersion.id,
      p.id,
      JSON.stringify(p.setupVersion),
      p.setupVersion.created,
    );
  if (p.snapshot)
    db.prepare(
      "INSERT OR IGNORE INTO evaluation_snapshots VALUES(?,?,?,?)",
    ).run(p.snapshot.id, p.id, JSON.stringify(p.snapshot), p.snapshot.approved);
}
function transaction(fn) {
  db.exec("BEGIN IMMEDIATE");
  try {
    const r = fn();
    db.exec("COMMIT");
    return r;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
app.get("/api/procurements", (req, res) => {
  const rows =
    req.user.role === "admin"
      ? db.prepare("SELECT data FROM procurements").all()
      : db
          .prepare(
            "SELECT data FROM procurements WHERE owner=? OR id IN(SELECT procurement_id FROM memberships WHERE user_id=?)",
          )
          .all(req.user.id, req.user.id);
  res.json(rows.map((r) => JSON.parse(r.data)));
});
app.post("/api/procurements", (req, res, next) => {
  try {
    if (req.user.role === "viewer") throw Error("Nincs jogosultság");
    if (typeof req.body.title !== "string" || !req.body.title.trim())
      throw Error("A tárgy kötelező");
    if (!number(req.body.estimate || "0").gte(0))
      throw Error("Hibás becsült érték");
    const p = {
      id: randomUUID(),
      title: req.body.title,
      reference: req.body.reference || "",
      organization: req.body.organization || "",
      estimate: req.body.estimate || "0",
      method: "lowest",
      minimum: "1",
      decimalPlaces: 3,
      zeroPriceRule: "clarify",
      items: [],
      requirements: [],
      bidders: [],
      phase: "setup",
      revision: 0,
      createdAt: new Date().toISOString(),
    };
    transaction(() => {
      db.prepare("INSERT INTO procurements VALUES(?,?,?)").run(
        p.id,
        req.user.id,
        JSON.stringify(p),
      );
      audit(p.id, req.user, "created", p);
    });
    res.json(p);
  } catch (e) {
    next(e);
  }
});
app.get("/api/procurements/:id", (req, res, next) => {
  try {
    res.json(access(req.params.id, req.user));
  } catch (e) {
    next(e);
  }
});
app.put("/api/procurements/:id/setup", (req, res, next) => {
  try {
    res.json(
      transaction(() => {
        const p = access(req.params.id, req.user, true);
        if (p.phase !== "setup")
          throw Error("A véglegesített módszer nem módosítható");
        if (req.body.revision !== p.revision)
          throw Error("Az ügy időközben módosult. Frissítse az oldalt.");
        for (const key of [
          "method",
          "minimum",
          "items",
          "requirements",
          "decimalPlaces",
        ])
          p[key] = req.body[key];
        validateSetup(p);
        p.revision++;
        save(p);
        audit(p.id, req.user, "setup_updated", p);
        return p;
      }),
    );
  } catch (e) {
    next(e);
  }
});
app.post("/api/procurements/:id/finalize", (req, res, next) => {
  try {
    res.json(
      transaction(() => {
        const p = access(req.params.id, req.user, true);
        if (p.phase !== "setup") throw Error("Már véglegesítve");
        validateSetup(p);
        p.phase = "bids";
        p.setupVersion = {
          id: randomUUID(),
          created: new Date().toISOString(),
          method: p.method,
          minimum: p.minimum,
          decimalPlaces: p.decimalPlaces ?? 3,
          zeroPriceRule: "clarify",
          items: p.items,
          requirements: p.requirements,
        };
        p.revision++;
        save(p);
        audit(p.id, req.user, "setup_finalized", p.setupVersion);
        return p;
      }),
    );
  } catch (e) {
    next(e);
  }
});
app.post("/api/procurements/:id/bidders", (req, res, next) => {
  try {
    res.json(
      transaction(() => {
        const p = access(req.params.id, req.user, true);
        if (p.snapshot) throw Error("Jóváhagyott ügy");
        if (!req.body.name?.trim()) throw Error("A cégnév kötelező");
        p.bidders.push({
          id: randomUUID(),
          name: req.body.name,
          status: "invited",
          compliance: "pending",
          versions: [],
          checks: {},
        });
        p.revision++;
        save(p);
        audit(p.id, req.user, "bidder_added", p.bidders.at(-1));
        return p;
      }),
    );
  } catch (e) {
    next(e);
  }
});
app.post("/api/procurements/:id/bidders/:bid", (req, res, next) => {
  try {
    res.json(
      transaction(() => {
        const p = access(req.params.id, req.user, true);
        if (p.phase === "setup" || p.snapshot)
          throw Error("Az ügy ebben az állapotban nem bírálható");
        const b = p.bidders.find((b) => b.id === req.params.bid);
        if (!b) throw Error("Nincs ajánlattevő");
        const { prices, status, checks, note, compliance } = req.body;
        if (!["pass", "fail", "clarify", "pending"].includes(compliance))
          throw Error("Megfelelőségi megállapítás szükséges");
        if (!["invited", "submitted", "withdrawn"].includes(status))
          throw Error("Hibás státusz");
        for (const r of p.requirements) {
          if (
            !["pass", "fail", "clarify", "pending", "na"].includes(
              checks?.[r.id]?.status,
            )
          )
            throw Error("Hiányzó megfelelőségi vizsgálat");
          if (
            ["fail", "na"].includes(checks[r.id].status) &&
            !checks[r.id].note?.trim()
          )
            throw Error("Indokolás szükséges");
        }
        if (prices) {
          for (const i of p.items) {
            if (prices[i.id] === undefined || !number(prices[i.id]).gte(0))
              throw Error("Hiányzó vagy negatív ár");
          }
          b.versions.push({
            id: randomUUID(),
            prices,
            note: note || "",
            created: new Date().toISOString(),
          });
        }
        b.status = status;
        b.compliance = compliance;
        b.checks = checks;
        p.revision++;
        save(p);
        audit(p.id, req.user, "bid_revision", b);
        return p;
      }),
    );
  } catch (e) {
    next(e);
  }
});
app.get("/api/procurements/:id/evaluation", (req, res, next) => {
  try {
    const p = access(req.params.id, req.user);
    res.json(p.snapshot?.evaluation || evaluate(p));
  } catch (e) {
    next(e);
  }
});
app.post("/api/procurements/:id/approve", (req, res, next) => {
  try {
    res.json(
      transaction(() => {
        const p = access(req.params.id, req.user, true);
        if (p.phase === "setup" || p.snapshot) throw Error("Hibás állapot");
        if (
          !/^\d{4}-\d{2}-\d{2}$/.test(req.body.evaluationDate) ||
          Number.isNaN(Date.parse(req.body.evaluationDate)) ||
          new Date(req.body.evaluationDate).toISOString().slice(0, 10) !==
            req.body.evaluationDate
        )
          throw Error("Érvényes bírálati dátum szükséges");
        const e = evaluate(p);
        const winner = e.ranked.find((r) => r.id === req.body.winner);
        if (!winner || e.needsClarification)
          throw Error("Csak értékelhető ajánlat javasolható");
        for (const k of [
          "reason",
          "technical",
          "reviewer",
          "job",
          "place",
          "evaluationDate",
          "contractDuration",
          "contractType",
        ])
          if (!req.body[k]?.trim()) throw Error("Minden döntési adat kötelező");
        if (
          !["individual", "framework"].includes(req.body.contractType) ||
          !number(req.body.contractValue).gte(0)
        )
          throw Error(
            "Szerződéstípus és nem negatív tervezett nettó érték szükséges",
          );
        if (e.ranked.length < 3 && !req.body.competitionJustification?.trim())
          throw Error(
            "Háromnál kevesebb értékelhető ajánlat külön indokolása szükséges",
          );
        p.snapshot = {
          id: randomUUID(),
          approved: new Date().toISOString(),
          actor: req.user.id,
          revision: p.revision,
          evaluation: e,
          decision: {
            ...req.body,
            calculationReason: justification(p, e, req.body.winner),
          },
          procurement: JSON.parse(JSON.stringify(p)),
        };
        p.phase = "approved";
        p.revision++;
        save(p);
        audit(p.id, req.user, "decision_approved", p.snapshot);
        return p;
      }),
    );
  } catch (e) {
    next(e);
  }
});
app.get("/api/procurements/:id/audit", (req, res, next) => {
  try {
    access(req.params.id, req.user);
    res.json(
      db
        .prepare(
          "SELECT action,actor,created,data FROM audit WHERE procurement_id=? ORDER BY id",
        )
        .all(req.params.id),
    );
  } catch (e) {
    next(e);
  }
});
app.post("/api/users", (req, res, next) => {
  try {
    if (req.user.role !== "admin")
      throw Error("Adminisztrátori jogosultság szükséges");
    const { email, password, role } = req.body;
    if (
      !email?.includes("@") ||
      password?.length < 12 ||
      !["admin", "reviewer", "viewer"].includes(role)
    )
      throw Error("Hibás felhasználói adatok");
    const id = randomUUID();
    db.prepare("INSERT INTO users(id,email,hash,role) VALUES(?,?,?,?)").run(
      id,
      email.toLowerCase(),
      hash(password),
      role,
    );
    audit(null, req.user, "user_created", { id, email, role });
    res.json({ id, email, role });
  } catch (e) {
    next(e);
  }
});
app.get("/api/users", (req, res, next) => {
  try {
    if (req.user.role !== "admin") throw Error("Admin szükséges");
    res.json(db.prepare("SELECT id,email,role,active FROM users").all());
  } catch (e) {
    next(e);
  }
});
app.post("/api/users/:id/revoke", (req, res, next) => {
  try {
    if (req.user.role !== "admin" || req.params.id === req.user.id)
      throw Error("Nem engedélyezett");
    transaction(() => {
      db.prepare("UPDATE users SET active=0 WHERE id=?").run(req.params.id);
      db.prepare("DELETE FROM sessions WHERE user_id=?").run(req.params.id);
    });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});
app.post("/api/procurements/:id/members", (req, res, next) => {
  try {
    if (req.user.role !== "admin") throw Error("Admin szükséges");
    access(req.params.id, req.user, true);
    db.prepare("INSERT OR IGNORE INTO memberships VALUES(?,?)").run(
      req.params.id,
      req.body.userId,
    );
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});
app.post("/api/password", (req, res, next) => {
  try {
    const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
    if (
      !verify(String(req.body.current), u.hash) ||
      req.body.password?.length < 12
    )
      throw Error("Hibás jelenlegi jelszó vagy túl rövid új jelszó");
    transaction(() => {
      db.prepare("UPDATE users SET hash=? WHERE id=?").run(
        hash(req.body.password),
        u.id,
      );
      db.prepare("DELETE FROM sessions WHERE user_id=?").run(u.id);
    });
    audit(null, req.user, "password_changed", { user: req.user.id });
    res.clearCookie("session").json({ ok: true });
  } catch (e) {
    next(e);
  }
});
app.post("/api/users/:id/reset-password", (req, res, next) => {
  try {
    if (req.user.role !== "admin" || req.body.password?.length < 12)
      throw Error("Admin és legalább 12 karakteres jelszó szükséges");
    transaction(() => {
      db.prepare("UPDATE users SET hash=? WHERE id=?").run(
        hash(req.body.password),
        req.params.id,
      );
      db.prepare("DELETE FROM sessions WHERE user_id=?").run(req.params.id);
    });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});
app.delete("/api/procurements/:id/members/:user", (req, res, next) => {
  try {
    if (req.user.role !== "admin") throw Error("Admin szükséges");
    access(req.params.id, req.user, true);
    db.prepare(
      "DELETE FROM memberships WHERE procurement_id=? AND user_id=?",
    ).run(req.params.id, req.params.user);
    audit(req.params.id, req.user, "membership_revoked", {
      user: req.params.user,
    });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 },
});
app.post("/api/templates", upload.single("file"), (req, res, next) => {
  try {
    if (req.user.role !== "admin") throw Error("Admin szükséges");
    if (req.body.confirmed !== "true")
      throw Error(
        "Csak jóváhagyott, személyes adatoktól és aláírásképektől megtisztított sablon használható",
      );
    validateTemplate(req.file.buffer);
    const id = randomUUID();
    db.prepare(
      "INSERT INTO templates(id,name,file,created,approved,approved_by,approved_at,checksum) VALUES(?,?,?,?,1,?,?,?)",
    ).run(
      id,
      req.file.originalname,
      req.file.buffer,
      new Date().toISOString(),
      req.user.id,
      new Date().toISOString(),
      createHash("sha256").update(req.file.buffer).digest("hex"),
    );
    res.json({ id });
  } catch (e) {
    next(e);
  }
});
app.get("/api/templates", (req, res) =>
  res.json(
    db
      .prepare("SELECT id,name,created,approved,approved_at FROM templates")
      .all(),
  ),
);
app.get("/api/templates/:id", (req, res, next) => {
  try {
    if (req.user.role !== "admin") throw Error("Admin szükséges");
    const t = db
      .prepare("SELECT * FROM templates WHERE id=?")
      .get(req.params.id);
    if (!t) throw Error("Nincs sablon");
    res.attachment("elokeszitett-sablon.docx").send(Buffer.from(t.file));
  } catch (e) {
    next(e);
  }
});
app.post("/api/templates/:id/approve", (req, res, next) => {
  try {
    if (req.user.role !== "admin" || req.body.confirmed !== true)
      throw Error(
        "Adminisztrátori sablon- és hatályossági jóváhagyás szükséges",
      );
    const t = db
      .prepare("SELECT * FROM templates WHERE id=?")
      .get(req.params.id);
    if (!t) throw Error("Nincs sablon");
    validateTemplate(t.file);
    transaction(() => {
      db.prepare(
        "UPDATE templates SET approved=1,approved_by=?,approved_at=? WHERE id=?",
      ).run(req.user.id, new Date().toISOString(), t.id);
      audit(null, req.user, "template_approved", { id: t.id });
    });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});
app.post(
  "/api/procurements/:id/documents/:bid",
  upload.single("file"),
  (req, res, next) => {
    try {
      const p = access(req.params.id, req.user, true);
      if (p.snapshot || !p.bidders.some((b) => b.id === req.params.bid))
        throw Error("Nem módosítható");
      if (!/\.(pdf|docx|xlsx|csv)$/i.test(req.file?.originalname))
        throw Error("Nem támogatott fájltípus");
      const id = randomUUID();
      db.prepare("INSERT INTO documents VALUES(?,?,?,?,?,?)").run(
        id,
        p.id,
        req.params.bid,
        path.basename(req.file.originalname),
        req.file.buffer,
        new Date().toISOString(),
      );
      audit(p.id, req.user, "document_added", {
        id,
        name: req.file.originalname,
      });
      res.json({ id });
    } catch (e) {
      next(e);
    }
  },
);
app.get("/api/procurements/:id/documents", (req, res, next) => {
  try {
    access(req.params.id, req.user);
    res.json(
      db
        .prepare(
          "SELECT id,bidder_id,name,created FROM documents WHERE procurement_id=? UNION ALL SELECT id,NULL AS bidder_id,name,created FROM generated_exports WHERE procurement_id=?",
        )
        .all(req.params.id, req.params.id),
    );
  } catch (e) {
    next(e);
  }
});
app.get("/api/documents/:id", (req, res, next) => {
  try {
    const d =
      db.prepare("SELECT * FROM documents WHERE id=?").get(req.params.id) ||
      db
        .prepare("SELECT * FROM generated_exports WHERE id=?")
        .get(req.params.id);
    if (!d) throw Error("Nincs dokumentum");
    access(d.procurement_id, req.user);
    res
      .set("Content-Type", "application/octet-stream")
      .attachment(d.name)
      .send(Buffer.from(d.file));
  } catch (e) {
    next(e);
  }
});
app.get("/api/procurements/:id/tender.xlsx", async (req, res, next) => {
  try {
    const p = access(req.params.id, req.user);
    validateSetup(p);
    res.attachment("ajanlati-artabla.xlsx").send(await tenderWorkbook(p));
  } catch (e) {
    next(e);
  }
});
app.post(
  "/api/procurements/:id/bidders/:bid/import",
  upload.single("file"),
  async (req, res, next) => {
    try {
      const p = access(req.params.id, req.user, true);
      if (p.phase === "setup" || p.snapshot)
        throw Error("Nem importálható ebben az állapotban");
      if (!p.bidders.some((b) => b.id === req.params.bid))
        throw Error("Nincs ajánlattevő");
      const wb = new ExcelJS.Workbook();
      if (/\.xlsx$/i.test(req.file?.originalname))
        await wb.xlsx.load(req.file.buffer);
      else if (/\.csv$/i.test(req.file?.originalname))
        await wb.csv.read(Readable.from(req.file.buffer), {
          map: (value) => value,
          parserOptions: { delimiter: ";", bom: true },
        });
      else
        throw Error("Csak XLSX vagy pontosvesszővel tagolt CSV importálható");
      const ws = wb.worksheets[0];
      const prices = {};
      if (!ws || ws.rowCount > p.items.length + 1) throw Error("Hibás ártábla");
      ws.eachRow((row, k) => {
        if (k === 1) return;
        const id = String(row.getCell(1).value || "");
        if (!p.items.some((i) => i.id === id) || prices[id] !== undefined)
          throw Error("Ismeretlen vagy ismételt tétel");
        const item = p.items.find((i) => i.id === id);
        if (
          String(row.getCell(2).value) !== item.name ||
          !number(row.getCell(3).value).eq(number(item.quantity)) ||
          String(row.getCell(4).value) !== item.unit ||
          !number(row.getCell(5).value).eq(number(item.weight))
        )
          throw Error(
            "Az ártábla feltételei eltérnek a véglegesített adatoktól",
          );
        const cell = row.getCell(6).value;
        if (cell && typeof cell === "object")
          throw Error("Képlet nem importálható egységárként");
        if (!number(cell).gte(0)) throw Error("Negatív ár");
        prices[id] = String(cell);
      });
      if (Object.keys(prices).length !== p.items.length)
        throw Error("Hiányos ártábla");
      res.json({ prices });
    } catch (e) {
      next(e);
    }
  },
);
app.get("/api/procurements/:id/export.xlsx", async (req, res, next) => {
  try {
    const p = access(req.params.id, req.user);
    if (!p.snapshot) throw Error("Jóváhagyott pillanatkép szükséges");
    const output = await comparisonWorkbook(p.snapshot);
    transaction(() => {
      db.prepare("INSERT INTO generated_exports VALUES(?,?,?,?,?,?,?)").run(
        randomUUID(),
        p.id,
        p.snapshot.id,
        null,
        "BidEval-osszehasonlitas.xlsx",
        output,
        new Date().toISOString(),
      );
      audit(p.id, req.user, "xlsx_generated", { snapshot: p.snapshot.id });
    });
    res.attachment("BidEval-osszehasonlitas.xlsx").send(output);
  } catch (e) {
    next(e);
  }
});
for (const format of ["docx", "pdf"])
  app.get("/api/procurements/:id/report." + format, async (req, res, next) => {
    try {
      const p = access(req.params.id, req.user);
      if (!p.snapshot) throw Error("Jóváhagyott pillanatkép szükséges");
      const t = db
        .prepare("SELECT * FROM templates WHERE id=?")
        .get(req.query.template);
      if (!t?.approved)
        throw Error("Jóváhagyott eredeti DOCX-sablon szükséges");
      const docx = generateReport(p.snapshot, t),
        output = format === "pdf" ? await renderPdf(docx, dir) : docx;
      transaction(() => {
        db.prepare("INSERT INTO generated_exports VALUES(?,?,?,?,?,?,?)").run(
          randomUUID(),
          p.id,
          p.snapshot.id,
          t.id,
          "Biralati-lap." + format,
          output,
          new Date().toISOString(),
        );
        audit(
          p.id,
          req.user,
          format === "docx" ? "report_generated" : "pdf_generated",
          { snapshot: p.snapshot.id, template: t.id },
        );
      });
      res
        .type(
          format === "pdf"
            ? "application/pdf"
            : "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
        .attachment("Biralati-lap." + format)
        .send(output);
    } catch (e) {
      next(e);
    }
  });
app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use(express.static("dist"));
app.use((err, req, res, next) =>
  res.status(400).json({ error: err.message || "Hiba" }),
);
const server = app.listen(
  Number(process.env.PORT || 3001),
  process.env.BIDEVAL_HOST || "127.0.0.1",
  () => console.log("BidEval server ready"),
);
process.on("SIGTERM", () =>
  server.close(() => {
    db.close();
    process.exit(0);
  }),
);
