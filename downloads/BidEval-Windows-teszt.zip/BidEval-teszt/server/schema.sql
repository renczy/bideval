CREATE TABLE IF NOT EXISTS line_items(id TEXT PRIMARY KEY,procurement_id TEXT NOT NULL REFERENCES procurements(id),name TEXT NOT NULL,quantity TEXT NOT NULL,unit TEXT NOT NULL,weight TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS requirements(id TEXT PRIMARY KEY,procurement_id TEXT NOT NULL REFERENCES procurements(id),name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bidders(id TEXT PRIMARY KEY,procurement_id TEXT NOT NULL REFERENCES procurements(id),name TEXT NOT NULL,status TEXT NOT NULL,compliance TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bid_versions(id TEXT PRIMARY KEY,bidder_id TEXT NOT NULL REFERENCES bidders(id),note TEXT,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bid_prices(version_id TEXT NOT NULL REFERENCES bid_versions(id),item_id TEXT NOT NULL REFERENCES line_items(id),unit_price TEXT NOT NULL,PRIMARY KEY(version_id,item_id));
CREATE TABLE IF NOT EXISTS compliance_checks(bidder_id TEXT NOT NULL REFERENCES bidders(id),requirement_id TEXT NOT NULL REFERENCES requirements(id),status TEXT NOT NULL,note TEXT,PRIMARY KEY(bidder_id,requirement_id));
CREATE TABLE IF NOT EXISTS evaluation_setups(id TEXT PRIMARY KEY,procurement_id TEXT NOT NULL REFERENCES procurements(id),data TEXT NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS evaluation_snapshots(id TEXT PRIMARY KEY,procurement_id TEXT NOT NULL REFERENCES procurements(id),data TEXT NOT NULL,created TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS immutable_version_update BEFORE UPDATE ON bid_versions BEGIN SELECT RAISE(ABORT,'Immutable bid version'); END;
CREATE TRIGGER IF NOT EXISTS immutable_price_update BEFORE UPDATE ON bid_prices BEGIN SELECT RAISE(ABORT,'Immutable bid price'); END;
CREATE TRIGGER IF NOT EXISTS immutable_setup_update BEFORE UPDATE ON evaluation_setups BEGIN SELECT RAISE(ABORT,'Immutable setup'); END;
CREATE TRIGGER IF NOT EXISTS immutable_snapshot_update BEFORE UPDATE ON evaluation_snapshots BEGIN SELECT RAISE(ABORT,'Immutable snapshot'); END;
CREATE TRIGGER IF NOT EXISTS immutable_audit_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT,'Immutable audit'); END;
CREATE TRIGGER IF NOT EXISTS immutable_audit_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT,'Immutable audit'); END;

CREATE TABLE IF NOT EXISTS generated_exports(id TEXT PRIMARY KEY,procurement_id TEXT NOT NULL REFERENCES procurements(id),snapshot_id TEXT NOT NULL REFERENCES evaluation_snapshots(id),template_id TEXT REFERENCES templates(id),name TEXT NOT NULL,file BLOB NOT NULL,created TEXT NOT NULL);
