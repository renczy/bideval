import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
const run = promisify(execFile);
export async function renderPdf(docx, dataDirectory) {
  const root = path.join(dataDirectory, "render-jobs");
  await fs.mkdir(root, { recursive: true, mode: 0o700 });
  const job = await fs.mkdtemp(path.join(root, "job-"));
  try {
    const file = path.join(job, "report.docx");
    await fs.writeFile(file, docx, { mode: 0o600 });
    await run(
      process.env.BIDEVAL_SOFFICE || "soffice",
      [
        "--headless",
        "-env:UserInstallation=" + pathToFileURL(path.join(job, "profile")).href,
        "--convert-to",
        "pdf",
        "--outdir",
        job,
        file,
      ],
      {
        timeout: 60000,
        maxBuffer: 1024 * 1024,
        env: { ...process.env, XDG_CACHE_HOME: path.join(job, "cache") },
      },
    );
    const pdf = await fs.readFile(path.join(job, "report.pdf"));
    if (pdf.subarray(0, 5).toString() !== "%PDF-")
      throw Error("Hibás PDF-kimenet");
    return pdf;
  } finally {
    await fs.rm(job, { recursive: true, force: true });
  }
}
