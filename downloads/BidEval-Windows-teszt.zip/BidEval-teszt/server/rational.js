// Exact rational arithmetic: prices, quantities, and repeating fractional weights.
const gcd = (a, b) => {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;
  while (b) {
    [a, b] = [b, a % b];
  }
  return a || 1n;
};
export default class Rational {
  constructor(v, d) {
    if (v instanceof Rational) {
      this.n = v.n;
      this.d = v.d;
      return;
    }
    if (d !== undefined) {
      this.n = BigInt(v);
      this.d = BigInt(d);
    } else {
      let s = String(v).trim();
      if (!/^[+-]?\d+(\.\d+)?$/.test(s)) throw Error("Hibás szám");
      const negative = s.startsWith("-");
      s = s.replace(/^[+-]/, "");
      const [a, b = ""] = s.split(".");
      this.n = BigInt(a + b) * (negative ? -1n : 1n);
      this.d = 10n ** BigInt(b.length);
    }
    if (this.d === 0n) throw Error("Nullával osztás");
    if (this.d < 0) {
      this.n = -this.n;
      this.d = -this.d;
    }
    const g = gcd(this.n, this.d);
    this.n /= g;
    this.d /= g;
  }
  plus(v) {
    v = new Rational(v);
    return new Rational(this.n * v.d + v.n * this.d, this.d * v.d);
  }
  minus(v) {
    v = new Rational(v);
    return new Rational(this.n * v.d - v.n * this.d, this.d * v.d);
  }
  mul(v) {
    v = new Rational(v);
    return new Rational(this.n * v.n, this.d * v.d);
  }
  div(v) {
    v = new Rational(v);
    return new Rational(this.n * v.d, this.d * v.n);
  }
  cmp(v) {
    v = new Rational(v);
    const x = this.n * v.d - v.n * this.d;
    return x < 0n ? -1 : x > 0n ? 1 : 0;
  }
  gt(v) {
    return this.cmp(v) > 0;
  }
  gte(v) {
    return this.cmp(v) >= 0;
  }
  eq(v) {
    return this.cmp(v) === 0;
  }
  isZero() {
    return this.n === 0n;
  }
  isFinite() {
    return true;
  }
  toString() {
    let n = this.n < 0n ? -this.n : this.n;
    const a = n / this.d;
    let r = n % this.d;
    let s = "";
    for (let i = 0; i < 80 && r; i++) {
      r *= 10n;
      s += r / this.d;
      r %= this.d;
    }
    return (this.n < 0n ? "-" : "") + a + (s ? "." + s : "");
  }
  fixed(places = 3) {
    if (!Number.isInteger(places) || places < 0 || places > 6)
      throw Error("Hibás kerekítés");
    const scale = 10n ** BigInt(places),
      abs = this.n < 0n ? -this.n : this.n;
    let q = (abs * scale) / this.d;
    const remainder = (abs * scale) % this.d;
    if (remainder * 2n >= this.d) q++;
    const digits = q.toString().padStart(places + 1, "0");
    return (
      (this.n < 0n && q !== 0n ? "-" : "") +
      (places ? digits.slice(0, -places) + "." + digits.slice(-places) : digits)
    );
  }
  exact() {
    return `${this.n}/${this.d}`;
  }
  static min(...xs) {
    return xs.reduce((a, b) => (a.cmp(b) <= 0 ? a : b));
  }
}
