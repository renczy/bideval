"""Prepare the private original form without reproducing the completed example's data."""
import argparse, copy, hashlib, json, zipfile
from pathlib import Path
from lxml import etree as E
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS={'w':W}
PARSER=E.XMLParser(resolve_entities=False,no_network=True)
def tag(name):return '{'+W+'}'+name

def text_of(node):return ''.join(node.xpath('.//w:t/text()',namespaces=NS))
def replace_text(node,text):
    paragraphs=[node] if node.tag==tag('p') else node.findall('w:p',NS)
    if not paragraphs:raise ValueError('Missing paragraph in original form')
    p=paragraphs[0]
    runs=p.findall('w:r',NS)
    r=copy.deepcopy(runs[0]) if runs else E.Element(tag('r'))
    for child in list(r):
        if child.tag!=tag('rPr'):r.remove(child)
    for index,segment in enumerate(text.split('\n')):
        if index:E.SubElement(r,tag('br'))
        t=E.SubElement(r,tag('t'));t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=segment
    for child in list(p):
        if child.tag!=tag('pPr'):p.remove(child)
    p.append(r)
    for extra in paragraphs[1:]:node.remove(extra)

def build(source,destination):
    with zipfile.ZipFile(source) as original:
        parts={n:original.read(n) for n in original.namelist()}
        root=E.fromstring(parts['word/document.xml'],PARSER);body=root.find('w:body',NS)
        tables=body.findall('w:tbl',NS);paragraphs=body.findall('w:p',NS)
        if len(tables)!=3 or len(tables[0].findall('w:tr',NS))!=7 or len(paragraphs)!=25:
            raise ValueError('The original form changed; inspect and version the mapping before preparation')
        # Keep all table/paragraph/run properties from the supplied original.
        fields=['procedure_id','subject','estimated_value','evaluation_date','organization','submitted_count','method']
        for row,field in zip(tables[0].findall('w:tr',NS),fields):replace_text(row.findall('w:tc',NS)[1],'{'+field+'}')
        summary=tables[1];rows=summary.findall('w:tr',NS);prototype=copy.deepcopy(rows[1])
        for row in rows[1:]:summary.remove(row)
        for cell,text in zip(prototype.findall('w:tc',NS),['{#offers}{name}','{summary_result}','{net_price}','{compliance}{/offers}']):replace_text(cell,text)
        summary.append(prototype)
        for row,field in zip(tables[2].findall('w:tr',NS),['contract_duration','contract_net_value','winner']):replace_text(row.findall('w:tc',NS)[1],'{'+field+'}')
        mapping={7:'Részletes számítások és ajánlatverziók: az értékelési mellékletben.',9:'{compliance_summary}',10:'{invalidity_reasons}',13:'Nyertes ajánlat nettó értéke: {winner_net_value} Ft. {technical_content}',14:'{reason}',15:'',16:'{competition_justification}',18:'Fenti adatok és a beérkezett ajánlatok alapján Előterjesztő javasolja a(z) {subject} tárgyban lefolytatott beszerzési eljárás lezárásaként a(z) {winner} ajánlatát elfogadni, vele {contract_duration} időtartamra {contract_net_value} Ft nettó összegű {contract_type} kötni a Társaság hatályos szabályzatai által meghatározott jóváhagyásokat követően.',20:'{approval_text}',21:'Értékelési pillanatkép: {snapshot_id}. Sablonverzió: {template_version}.',23:'A versenyeztetést és a bírálatot lebonyolította: {reviewer}, {reviewer_job}',24:'{place}, {date}\n\nAláírás helye: ______________________________'}
        for index,text in mapping.items():replace_text(paragraphs[index],text)
        # Continuation pages reuse the original form's table and body styles.
        section=body.find('w:sectPr',NS)
        def append(node):body.insert(body.index(section),node)
        page=copy.deepcopy(paragraphs[4]);replace_text(page,'')
        run=E.SubElement(page,tag('r'));br=E.SubElement(run,tag('br'));br.set(tag('type'),'page');append(page)
        heading=copy.deepcopy(paragraphs[2]);replace_text(heading,'Értékelési melléklet');append(heading)
        explanation=copy.deepcopy(paragraphs[5]);replace_text(explanation,'{calculation_method_description}');append(explanation)
        loop=copy.deepcopy(paragraphs[5]);replace_text(loop,'{#evaluation_details}');append(loop)
        bidder_heading=copy.deepcopy(paragraphs[5]);replace_text(bidder_heading,'{name} – értékelt ajánlatverzió: {version}');append(bidder_heading)
        detail=copy.deepcopy(tables[1]);drows=detail.findall('w:tr',NS)
        for cell,text in zip(drows[0].findall('w:tc',NS),['Értékelési tétel','Nettó egységár (Ft)','Mennyiség / súly','Számított eredmény']):replace_text(cell,text)
        props=drows[0].find('w:trPr',NS)
        if props is None:props=E.Element(tag('trPr'));drows[0].insert(0,props)
        if props.find('w:tblHeader',NS) is None:E.SubElement(props,tag('tblHeader'))
        for cell,text in zip(drows[1].findall('w:tc',NS),['{#items}{name}','{price}','{coefficient}','{score}{/items}']):replace_text(cell,text)
        append(detail)
        total=copy.deepcopy(paragraphs[5]);replace_text(total,'Nettó ajánlati összeg: {net_price} Ft. Értékelési eredmény: {score}. Rangsor: {rank}.');append(total)
        end_loop=copy.deepcopy(paragraphs[5]);replace_text(end_loop,'{/evaluation_details}');append(end_loop)
        history=copy.deepcopy(paragraphs[5]);replace_text(history,'Ajánlatverziók és megfelelőségi megállapítások');append(history)
        versions_loop=copy.deepcopy(paragraphs[5]);replace_text(versions_loop,'{#bid_history}');append(versions_loop)
        versions=copy.deepcopy(paragraphs[5]);replace_text(versions,'{name}: {version_summary}\nMegfelelőség: {compliance_summary}');append(versions)
        versions_end=copy.deepcopy(paragraphs[5]);replace_text(versions_end,'{/bid_history}');append(versions_end)
        # Remove cached bindings, comments and old document author metadata.
        for item in root.xpath('.//w:dataBinding|.//w:commentRangeStart|.//w:commentRangeEnd|.//w:commentReference',namespaces=NS):item.getparent().remove(item)
        parts['word/document.xml']=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
        if 'word/settings.xml' in parts:
            settings=E.fromstring(parts['word/settings.xml'],PARSER);u=settings.find('w:updateFields',NS)
            if u is None:u=E.SubElement(settings,tag('updateFields'))
            u.set(tag('val'),'true');parts['word/settings.xml']=E.tostring(settings,xml_declaration=True,encoding='UTF-8',standalone=True)
        removed={n for n in parts if n.startswith('customXml/') or 'comments' in n.lower() or n.startswith('_xmlsignatures/') or n=='docProps/custom.xml'}
        for name in list(parts):
            if name in removed:continue
            if name.endswith('.rels'):
                rel=E.fromstring(parts[name],PARSER);changed=False
                for item in list(rel):
                    target=item.get('Target','').lower()
                    if any(k in target for k in ['customxml','comments','_xmlsignatures','docprops/custom']):rel.remove(item);changed=True
                if changed:parts[name]=E.tostring(rel,xml_declaration=True,encoding='UTF-8',standalone=True)
        types=E.fromstring(parts['[Content_Types].xml'],PARSER)
        for item in list(types):
            if item.get('PartName','').lstrip('/') in removed:types.remove(item)
        parts['[Content_Types].xml']=E.tostring(types,xml_declaration=True,encoding='UTF-8',standalone=True)
        if 'docProps/core.xml' in parts:
            core=E.fromstring(parts['docProps/core.xml'],PARSER)
            for e in core:
                if E.QName(e).localname in ['creator','lastModifiedBy','title','subject','description','keywords']:e.text=''
            parts['docProps/core.xml']=E.tostring(core,xml_declaration=True,encoding='UTF-8',standalone=True)
        destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(destination,'w') as out:
            for info in original.infolist():
                if info.filename not in removed:out.writestr(copy.copy(info),parts[info.filename])
        # Preservation is checked on actual bytes, without logging private reference data.
        preserved=[n for n in parts if n.startswith('word/header') or n.startswith('word/media/') or n in ['word/styles.xml','word/fontTable.xml','word/theme/theme1.xml']]
        with zipfile.ZipFile(destination) as out:
            assert all(original.read(n)==out.read(n) for n in preserved)
        return {'preserved_parts':len(preserved),'media_count':len([n for n in parts if n.startswith('word/media/')]),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest()}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
    print(json.dumps(build(args.input,args.output)))
