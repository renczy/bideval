import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": "http://127.0.0.1:" + (process.env.BIDEVAL_API_PORT || "3001"),
    },
  },
  test: { include: ["tests/**/*.test.js"] },
});
