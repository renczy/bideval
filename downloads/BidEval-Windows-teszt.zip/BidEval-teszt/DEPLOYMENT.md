# Futtatás és publikálási előkészítés

## Helyi fejlesztői környezet

- Node 24+, npm; `npm ci --cache /workspace/.npm-cache`.
- Python 3 venv: `python3 -m venv .venv-docs`; `.venv-docs/bin/python -m pip install -r requirements-documents.txt --cache-dir /workspace/.pip-cache`.
- Helyi PDF-renderer: `soffice --version`; opcionális elérési út `BIDEVAL_SOFFICE`.
- Privát eredeti mellett `npm run template:prepare`; referenciák ellenőrzése `npm run documents:validate`.
- `npm run build`, `npm start`; első admin: külön interaktív terminálban `npm run admin`.
- Fejlesztői frontend: `npm run dev`; szükséges API: `npm run server`.
- Az adatkönyvtár megmarad, a folyamatokat új környezetben újra kell indítani.
- Az onboarding UI nem szolgáltat helyi webelőnézetet. A tesztek belső HTTP-kéréseket használnak.

| Környezeti változó      | Jelentés                                                                                                                      |
| ----------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| BIDEVAL_DATA_DIR        | Adatkönyvtár; alapérték `.data`                                                                                               |
| PORT                    | API/statikus szerver portja; alapérték `3001`                                                                                 |
| BIDEVAL_HOST            | Alapérték `127.0.0.1`; külső hálózatra csak megfelelő TLS és hozzáférési kontroll után                                        |
| BIDEVAL_FRONTEND_ORIGIN | Pontosan engedélyezett frontend eredetek, vesszővel; alapérték a két helyi 5173-as eredet                                     |
| BIDEVAL_HTTPS           | `1`: Secure cookie; TLS mögött kötelező                                                                                       |
| BIDEVAL_BOOTSTRAP_TOKEN | Opcionális bizalmas egyszeri admin-inicializálási token. Ne commitold és ne add meg chatben. CLI-admin mellett nem szükséges. |
| BIDEVAL_API_PORT        | Vite proxy célportja                                                                                                          |
| BIDEVAL_CHROMIUM        | Playwright böngésző elérési útja                                                                                              |

Nem kell új GitHub-token: a meglévő platformproxy read-only Git-hozzáférése működött. Nincs fizetős szolgáltatás aktiválva.

## Felhős célintegráció szükséges lépései

1. Supabase-projekt létrehozása vagy meglévő projekt kiválasztása; nyilvános regisztráció kikapcsolása és adminisztrátori meghívások használata.
2. Projekt URL és publikus publishable kulcs megadása környezeti beállításokban. Service-role kulcs kizárólag backend számára adható meg biztonságos beállításban; frontendbe nem kerülhet. Jelenleg az alkalmazás ezeket még nem olvassa, adapterfejlesztés szükséges.
3. Az előkészített migráció felülvizsgálata, tranzakciós műveletek implementálása és RLS tesztelése admin/bíráló/megtekintő és idegen ügy esetén.
4. Privát dokumentumtárolás és rövid lejáratú jogosult letöltés bekötése.
5. Az előkészített eredeti DOCX-sablon vállalati jóváhagyása. A privát referenciák nem részei a Gitnek. Külön Excel-referencia továbbra is hiányzik.
6. A működő helyi DOCX/PDF-renderelés áthelyezése stabil, erőforrás-korlátozott konténerbe; ismételt vizuális és Word-elfogadás.
7. Cloudflare Pages frontend és Supabase backend integrációja, HTTPS, meghívásos Auth, visszaállítási URL-ek és funkcionális elfogadás.
8. Külön felhasználói jóváhagyás után éles publikálás.

A működő helyi API-t nem lehet Cloudflare Pages statikus tárhelyre egyszerűen feltölteni. Éles közzététel ebben a munkamenetben nem történt.
