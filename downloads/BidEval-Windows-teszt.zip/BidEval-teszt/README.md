# BidEval Windows fiktív teszt

Először nyisd meg a KIPROBALAS.html útmutatót. Indító: INDITAS-TESZT.cmd. A csomag nem tartalmaz céges sablont, dokumentummintát vagy személyes felhasználói fiókot.
