import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
const root=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const data=path.join(root,'teszt-adatok');
const token=randomBytes(32).toString('hex');
const port=3002;
const env={...process.env,BIDEVAL_DATA_DIR:data,PORT:String(port),BIDEVAL_HOST:'127.0.0.1',BIDEVAL_BOOTSTRAP_TOKEN:token};
delete env.BIDEVAL_HTTPS;
delete env.BIDEVAL_FRONTEND_ORIGIN;
if(!env.BIDEVAL_SOFFICE && process.platform==='win32'){
 for(const dir of [process.env.ProgramFiles,process.env['ProgramFiles(x86)']]){
  if(!dir)continue;
  const candidate=path.join(dir,'LibreOffice','program','soffice.exe');
  if(fs.existsSync(candidate)){env.BIDEVAL_SOFFICE=candidate;break;}
 }
}
const server=spawn(process.execPath,['server/index.js'],{cwd:root,env,stdio:['inherit','pipe','inherit']});
let opened=false;
server.stdout.on('data',async d=>{
 process.stdout.write(d);
 if(opened||!d.toString().includes('ready'))return;
 opened=true;
 try{
  const response=await fetch('http://127.0.0.1:'+port+'/api/status');
  const status=await response.json();if(!response.ok||typeof status.bootstrap!=='boolean')throw Error('Nem megfelelő státusz');
  const text=status.bootstrap?`<h2>1. Első adminfiók létrehozása</h2><p>Másold ki az alábbi egyszer használható telepítési tokent (jelöld ki, majd Ctrl+C). Az alkalmazásban illeszd a Telepítési token mezőbe. Add meg a saját e-mail-címedet és egy legalább 12 karakteres jelszót. A jelszót kizárólag az alkalmazásban add meg, chatbe vagy hibajelentésbe ne írd.</p><textarea readonly rows="3" cols="70">${token}</textarea><p>A Fiók létrehozása gomb után az áttekintés nyílik meg. Később e-maillel és jelszóval lehet belépni.</p>`:'<h2>Az adminfiók már létezik</h2><p>Az alkalmazásban jelentkezz be a korábban választott e-maillel és jelszóval.</p>';
  const html=`<!doctype html><html lang="hu"><meta charset="utf-8"><title>BidEval – fiktív kipróbálás</title><style>body{font:18px system-ui;max-width:850px;margin:40px auto;padding:20px;line-height:1.5}textarea{max-width:100%}a{color:#075e47}</style><h1>BidEval – elkülönített fiktív teszt</h1><p>Ez a saját gépeden futó tesztpéldány. Ne tölts bele valódi ajánlatot vagy személyes ügyadatot.</p>${text}<h2>2. Alkalmazás megnyitása</h2><p><a href="http://127.0.0.1:${port}">BidEval tesztalkalmazás megnyitása</a></p><p>Válaszd a FIKTÍV TESZT – granulátum és szállítás ügyet, majd a 3. Bírálat és döntés fület.</p><p>Részletes segítség: a csomag KIPROBALAS.html fájlja. Ez a megosztható csomag nem tartalmaz céges sablont vagy dokumentummintát. Az összehasonlító Excel a döntés után letölthető. Hivatalos DOCX/PDF csak külön, helyben feltöltött és jóváhagyott sablonnal készíthető.</p><p>Az indítóablak maradjon nyitva. Leállítás: Ctrl+C ebben az ablakban. A tesztadatok megmaradnak.</p></html>`;
  const file=path.join(data,'elso-belepes.html');fs.writeFileSync(file,html,{mode:0o600});
  console.log('Kész. A böngészőben megnyíló útmutatót kövesd. Leállítás: Ctrl+C.');
  if(process.env.BIDEVAL_NO_OPEN!=='1'){
   const url=pathToFileURL(file).href;
   const opener=process.platform==='win32'?spawn('rundll32.exe',['url.dll,FileProtocolHandler',url],{stdio:'ignore'}):spawn(process.platform==='darwin'?'open':'xdg-open',[url],{stdio:'ignore'});
   opener.on('error',()=>console.log('Nyisd meg kézzel a teszt-adatok/elso-belepes.html fájlt.'));
  }
 }catch(e){console.error('Az indulás ellenőrzése nem sikerült:',e.message);server.kill();process.exitCode=1;}
});
server.on('exit',code=>{if(code)console.error('A szerver nem indult el. Ha a port foglalt, zárd be a korábbi tesztindító ablakot.');process.exitCode=code??0;});
server.on('error',e=>{console.error(e.message);process.exitCode=1;});
process.on('SIGINT',()=>server.kill('SIGINT'));
process.on('SIGTERM',()=>server.kill('SIGTERM'));
