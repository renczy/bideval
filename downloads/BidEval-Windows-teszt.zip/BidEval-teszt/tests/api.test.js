import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { spawn } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { randomBytes } from "node:crypto";
import ExcelJS from "exceljs";
import { DatabaseSync } from "node:sqlite";
import PizZip from "pizzip";
const dir = mkdtempSync(path.join(tmpdir(), "bideval-test-")),
  token = randomBytes(32).toString("hex"),
  base = "http://127.0.0.1:3099";
let proc, cookie, p, viewer, other;
const password = "FiktivTesztJelszo123!";
async function request(route, body, method, c = cookie) {
  const r = await fetch(base + "/api" + route, {
    method: method || (body ? "POST" : "GET"),
    headers: {
      ...(body instanceof FormData
        ? {}
        : { "Content-Type": "application/json" }),
      ...(c ? { cookie: c } : {}),
    },
    body: body
      ? body instanceof FormData
        ? body
        : JSON.stringify(body)
      : undefined,
  });
  return r;
}
async function json(route, body, method, c) {
  const r = await request(route, body, method, c);
  const d = await r.json();
  if (!r.ok) throw Error(d.error);
  return d;
}
beforeAll(async () => {
  proc = spawn(process.execPath, ["server/index.js"], {
    env: {
      ...process.env,
      PORT: "3099",
      BIDEVAL_DATA_DIR: dir,
      BIDEVAL_BOOTSTRAP_TOKEN: token,
    },
    stdio: "pipe",
  });
  await new Promise((resolve, reject) => {
    proc.stdout.on("data", (d) => {
      if (d.toString().includes("ready")) resolve();
    });
    proc.on("exit", (code) => reject(Error("Server exit " + code)));
    setTimeout(() => reject(Error("Startup timeout")), 10000).unref();
  });
  await json("/bootstrap", { token, email: "admin@example.test", password });
  const r = await request("/login", { email: "admin@example.test", password });
  cookie = r.headers.get("set-cookie").split(";")[0];
}, 15000);
afterAll(async () => {
  proc?.kill();
  await new Promise((r) => proc?.once("exit", r));
  rmSync(dir, { recursive: true, force: true });
});
describe("Biztonságos beszerzési munkafolyamat", () => {
  it("hitelesítés nélkül nem olvasható", async () =>
    expect(
      (await request("/procurements", undefined, undefined, "")).status,
    ).toBe(401));
  it("egyszeri admin létrehozás és idegen eredet tiltva", async () => {
    expect(
      (
        await request("/bootstrap", {
          token,
          email: "x@example.test",
          password,
        })
      ).status,
    ).toBe(400);
    const r = await fetch(base + "/api/procurements", {
      method: "POST",
      headers: {
        cookie,
        "Content-Type": "application/json",
        Origin: "https://foreign.example",
      },
      body: JSON.stringify({ title: "x" }),
    });
    expect(r.status).toBe(403);
  });
  it("ügy és értékelési feltételek menthetők", async () => {
    p = await json("/procurements", {
      title: "Fiktív granulátumbeszerzés",
      reference: "TEST-001",
      organization: "Fiktív szervezet",
      estimate: "2000",
    });
    p = await json(
      "/procurements/" + p.id + "/setup",
      {
        revision: p.revision,
        method: "lowest",
        minimum: "1",
        items: [
          {
            id: "a",
            name: "Granulátum",
            unit: "zsák",
            quantity: "10",
            weight: "90",
          },
          {
            id: "b",
            name: "Szállítás",
            unit: "alkalom",
            quantity: "1",
            weight: "10",
          },
        ],
        requirements: [{ id: "r", name: "Műszaki megfelelőség" }],
      },
      "PUT",
    );
    expect(p.items).toHaveLength(2);
  });
  it("konkurens szerkesztés nem ír felül adatokat", async () =>
    expect(
      (
        await request(
          "/procurements/" + p.id + "/setup",
          { ...p, revision: 0 },
          "PUT",
        )
      ).status,
    ).toBe(400));
  it("véglegesített feltételek nem módosíthatók", async () => {
    p = await json("/procurements/" + p.id + "/finalize", {});
    expect(p.setupVersion.id).toBeTruthy();
    expect(
      (await request("/procurements/" + p.id + "/setup", p, "PUT")).status,
    ).toBe(400);
  });
  it("a kiküldött XLSX egységárai importálhatók, a feltételek nem változnak", async () => {
    p = await json("/procurements/" + p.id + "/bidders", {
      name: "Fiktív Alfa",
    });
    const r = await request("/procurements/" + p.id + "/tender.xlsx");
    expect(r.status).toBe(200);
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(Buffer.from(await r.arrayBuffer()));
    wb.worksheets[0].getCell("F2").value = 99.5;
    wb.worksheets[0].getCell("F3").value = 50;
    const f = new FormData();
    f.set("file", new Blob([await wb.xlsx.writeBuffer()]), "fiktiv.xlsx");
    const data = await json(
      "/procurements/" + p.id + "/bidders/" + p.bidders[0].id + "/import",
      f,
    );
    expect(data.prices).toEqual({ a: "99.5", b: "50" });
    expect((await json("/procurements/" + p.id)).setupVersion.id).toBe(
      p.setupVersion.id,
    );
    wb.worksheets[0].getCell("F2").value = { formula: "1+1", result: 2 };
    const invalid = new FormData();
    invalid.set(
      "file",
      new Blob([await wb.xlsx.writeBuffer()]),
      "formula.xlsx",
    );
    expect(
      (
        await request(
          "/procurements/" + p.id + "/bidders/" + p.bidders[0].id + "/import",
          invalid,
        )
      ).status,
    ).toBe(400);
  });
  it("három partner és verziózott árak rögzíthetők", async () => {
    for (const name of ["Fiktív Béta", "Fiktív Gamma"])
      p = await json("/procurements/" + p.id + "/bidders", { name });
    for (let i = 0; i < 3; i++)
      p = await json("/procurements/" + p.id + "/bidders/" + p.bidders[i].id, {
        status: "submitted",
        compliance: "pass",
        prices: { a: String(100 + i * 20), b: "50" },
        checks: { r: { status: "pass", note: "Ellenőrizve" } },
        note: "Eredeti ajánlat",
      });
    const b = p.bidders[1];
    p = await json("/procurements/" + p.id + "/bidders/" + b.id, {
      status: "submitted",
      compliance: "pass",
      prices: { a: "90", b: "50" },
      checks: { r: { status: "pass", note: "Ellenőrizve" } },
      note: "Ártárgyalás",
    });
    expect(p.bidders[1].versions).toHaveLength(2);
    expect(p.bidders[1].versions[0].prices.a).toBe("120");
  });
  it("a legfrissebb árakkal helyesen rangsorol", async () => {
    const e = await json("/procurements/" + p.id + "/evaluation");
    expect(e.ranked[0].name).toBe("Fiktív Béta");
    expect(e.ranked[0].total).toBe("950");
  });
  it("felhasználói és ügyjogosultságok szerveroldalon érvényesülnek", async () => {
    viewer = await json("/users", {
      email: "viewer@example.test",
      password,
      role: "viewer",
    });
    other = await json("/users", {
      email: "other@example.test",
      password,
      role: "reviewer",
    });
    let r = await request("/login", { email: viewer.email, password });
    const vc = r.headers.get("set-cookie").split(";")[0];
    expect(await json("/procurements", undefined, undefined, vc)).toEqual([]);
    expect(
      (await request("/procurements/" + p.id, undefined, undefined, vc)).status,
    ).toBe(400);
    await json("/procurements/" + p.id + "/members", { userId: viewer.id });
    expect((await json("/procurements", undefined, undefined, vc)).length).toBe(
      1,
    );
    expect(
      (
        await request(
          "/procurements/" + p.id + "/bidders",
          { name: "Forbidden" },
          undefined,
          vc,
        )
      ).status,
    ).toBe(400);
    await json("/users/" + viewer.id + "/revoke", {});
    expect((await request("/me", undefined, undefined, vc)).status).toBe(401);
  });
  it("privát dokumentumokat csak engedélyezett felhasználó tölthet le", async () => {
    const f = new FormData();
    f.set("file", new Blob(["fiktiv,adat"]), "fiktiv.csv");
    const d = await json(
      "/procurements/" + p.id + "/documents/" + p.bidders[0].id,
      f,
    );
    expect((await request("/documents/" + d.id)).status).toBe(200);
    const r = await request("/login", { email: other.email, password });
    const c = r.headers.get("set-cookie").split(";")[0];
    expect(
      (await request("/documents/" + d.id, undefined, undefined, c)).status,
    ).toBe(400);
  });
  it("export csak közös jóváhagyott pillanatképből készül", async () => {
    expect(
      (await request("/procurements/" + p.id + "/export.xlsx")).status,
    ).toBe(400);
    const e = await json("/procurements/" + p.id + "/evaluation");
    p = await json("/procurements/" + p.id + "/approve", {
      winner: e.ranked[0].id,
      reason:
        "A megfelelő ajánlatok közül a legalacsonyabb összesített nettó ár.",
      technical: "10 zsák granulátum egyszeri szállítással",
      reviewer: "Teszt Bíráló",
      job: "Beszerző",
      place: "Tesztváros",
      evaluationDate: "2026-10-11",
      contractDuration: "2026. november",
      contractType: "individual",
      contractValue: "950",
    });
    expect(p.snapshot.id).toBeTruthy();
    expect(
      (await request("/procurements/" + p.id + "/bidders", { name: "Late" }))
        .status,
    ).toBe(400);
    const r = await request("/procurements/" + p.id + "/export.xlsx");
    expect(r.status).toBe(200);
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(Buffer.from(await r.arrayBuffer()));
    expect(wb.worksheets[0].getCell("C1").value).toBe(p.snapshot.id);
    expect(wb.worksheets[0].getCell("E6").value.result).toBe(950);
  });
  it("eredeti sablon hiányában nem készül hamis hivatalos lap", async () =>
    expect(
      (await request("/procurements/" + p.id + "/report.docx")).status,
    ).toBe(400));
  it("sablonfeldolgozás megőrzi a fejlécet és a stílusokat", async () => {
    const z = new PizZip();
    z.file(
      "[Content_Types].xml",
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/></Types>',
    );
    z.file(
      "_rels/.rels",
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
    );
    z.file(
      "word/document.xml",
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>{subject}</w:t></w:r></w:p><w:p><w:r><w:t>{winner} – {winner_net_value} – {snapshot_id} – {template_version} – {procedure_id} – {estimated_value} – {evaluation_date} – {organization} – {submitted_count} – {method} – {technical_content} – {reason} – {reviewer} – {reviewer_job} – {place} – {date} – {#offers}{name}{/offers} – {#evaluation_details}{name}{/evaluation_details}</w:t></w:r></w:p><w:sectPr/></w:body></w:document>',
    );
    const header =
      '<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:r><w:t>FIKTÍV SZABÁLYZATI FEJLÉC</w:t></w:r></w:p></w:hdr>';
    z.file("word/header1.xml", header);
    z.file(
      "word/styles.xml",
      '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>',
    );
    const f = new FormData();
    f.set("confirmed", "true");
    f.set(
      "file",
      new Blob([z.generate({ type: "nodebuffer" })]),
      "fiktiv-sablon.docx",
    );
    const t = await json("/templates", f);
    const r = await request(
      "/procurements/" + p.id + "/report.docx?template=" + t.id,
    );
    expect(r.status).toBe(200);
    const output = new PizZip(Buffer.from(await r.arrayBuffer()));
    expect(output.file("word/header1.xml").asText()).toBe(header);
    expect(output.file("word/styles.xml").asText()).toBe(
      z.file("word/styles.xml").asText(),
    );
    expect(output.file("word/document.xml").asText()).toContain("Fiktív Béta");
    expect(output.file("word/document.xml").asText()).toContain(p.snapshot.id);
    expect(output.file("word/document.xml").asText()).not.toContain(
      "{subject}",
    );
  });
  it("adatok és audit előzmények visszaolvashatók", async () => {
    const saved = await json("/procurements/" + p.id);
    expect(saved.snapshot.id).toBe(p.snapshot.id);
    const events = await json("/procurements/" + p.id + "/audit");
    expect(events.some((e) => e.action === "setup_finalized")).toBe(true);
    expect(events.some((e) => e.action === "report_generated")).toBe(true);
  });
  it("a relációs tárolás megőrzi a verziókat és archiválja az exportokat", () => {
    const read = new DatabaseSync(path.join(dir, "bideval.sqlite"));
    expect(read.prepare("SELECT count(*) n FROM bidders").get().n).toBe(3);
    expect(read.prepare("SELECT count(*) n FROM bid_versions").get().n).toBe(4);
    expect(read.prepare("SELECT count(*) n FROM bid_prices").get().n).toBe(8);
    expect(
      read.prepare("SELECT count(*) n FROM generated_exports").get().n,
    ).toBe(2);
    expect(() =>
      read.prepare("UPDATE bid_versions SET note='changed'").run(),
    ).toThrow();
    read.close();
  });
  it("jelszócsere és admin-visszaállítás megszünteti a régi munkameneteket", async () => {
    const u = await json("/users", {
      email: "reset@example.test",
      password,
      role: "reviewer",
    });
    let r = await request("/login", { email: u.email, password });
    const old = r.headers.get("set-cookie").split(";")[0];
    await json(
      "/password",
      { current: password, password: "MasikFiktivJelszo123!" },
      undefined,
      old,
    );
    expect((await request("/me", undefined, undefined, old)).status).toBe(401);
    expect((await request("/login", { email: u.email, password })).status).toBe(
      400,
    );
    r = await request("/login", {
      email: u.email,
      password: "MasikFiktivJelszo123!",
    });
    const changed = r.headers.get("set-cookie").split(";")[0];
    await json("/users/" + u.id + "/reset-password", {
      password: "HarmadikFiktivJelszo123!",
    });
    expect((await request("/me", undefined, undefined, changed)).status).toBe(
      401,
    );
  });
  it("újraindítás után is rendelkezésre állnak az ügyadatok", async () => {
    await new Promise((resolve) => {
      proc.once("exit", resolve);
      proc.kill("SIGTERM");
    });
    proc = spawn(process.execPath, ["server/index.js"], {
      env: { ...process.env, PORT: "3099", BIDEVAL_DATA_DIR: dir },
      stdio: "pipe",
    });
    await new Promise((resolve, reject) => {
      proc.stdout.on("data", (d) => {
        if (d.toString().includes("ready")) resolve();
      });
      proc.on("exit", () => reject(Error("Restart failed")));
    });
    const saved = await json("/procurements/" + p.id);
    expect(saved.snapshot.id).toBe(p.snapshot.id);
    expect(saved.bidders[1].versions).toHaveLength(2);
  });
});
