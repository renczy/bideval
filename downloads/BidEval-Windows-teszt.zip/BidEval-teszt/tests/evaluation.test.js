import { describe, it, expect } from "vitest";
import { evaluate, number, validateSetup } from "../server/evaluation.js";
const p = (method = "lowest") => ({
  method,
  minimum: "1",
  items: [
    { id: "a", name: "Termék", quantity: "10", unit: "db", weight: "90" },
    {
      id: "b",
      name: "Szállítás",
      quantity: "1",
      unit: "alkalom",
      weight: "10/3",
    },
  ],
  requirements: [{ id: "r", name: "Műszaki megfelelőség" }],
  bidders: [
    {
      id: "x",
      name: "Fiktív Alfa",
      status: "submitted",
      compliance: "pass",
      checks: { r: { status: "pass" } },
      versions: [{ id: "v1", prices: { a: "100", b: "100" } }],
    },
    {
      id: "y",
      name: "Fiktív Béta",
      status: "submitted",
      compliance: "pass",
      checks: { r: { status: "pass" } },
      versions: [{ id: "v2", prices: { a: "120", b: "0" } }],
    },
    {
      id: "z",
      name: "Fiktív Gamma",
      status: "invited",
      versions: [],
      checks: {},
    },
  ],
});
describe("Bírálati matematika", () => {
  it("mennyiségekkel számol és nem értékeli a be nem érkezett ajánlatot", () => {
    const e = evaluate(p());
    expect(e.ranked[0].id).toBe("x");
    expect(e.ranked[0].total).toBe("1100");
    expect(e.rows[2].reason).toBe("Nem érkezett ajánlat");
  });
  it("elkülöníti az összehasonlító és szerződéses értéket", () => {
    const e = evaluate(p("weighted"));
    expect(e.ranked[0].total).not.toBe(e.ranked[0].value);
  });
  it("nulla áras pontozást tisztázásra blokkol", () =>
    expect(evaluate(p("points")).needsClarification).toBe(true));
  it("csak igazoltan megfelelő ajánlatokat pontoz", () => {
    const x = p("points");
    x.bidders[1].checks.r.status = "fail";
    expect(evaluate(x).ranked[0].value.startsWith("93.333")).toBe(true);
  });
  it("pontos törtszámokat kezel", () =>
    expect(number("10/3").mul(3).toString()).toBe("10"));
  it("holtversenyben azonos rangot ad", () => {
    const x = p();
    x.bidders[1].versions[0].prices = { a: "100", b: "100" };
    expect(evaluate(x).tie).toBe(true);
    expect(evaluate(x).ranked.map((r) => r.rank)).toEqual([1, 1]);
  });
  it("hiányzó vagy negatív ár nem értékelhető", () => {
    const x = p();
    x.bidders[0].versions[0].prices.a = "";
    x.bidders[1].versions[0].prices.a = "-1";
    expect(evaluate(x).ranked).toHaveLength(0);
  });
  it("a legfrissebb ajánlatverziót értékeli", () => {
    const x = p();
    x.bidders[1].versions.push({ id: "new", prices: { a: "50", b: "0" } });
    expect(evaluate(x).ranked[0].version).toBe("new");
  });
  it("elutasítja a hibás ponttartományt", () => {
    const x = p("points");
    x.minimum = "100";
    expect(() => validateSetup(x)).toThrow();
  });
  it("nincs fix ajánlattevő- vagy tételkorlát", () => {
    const x = p();
    x.items = Array.from({ length: 20 }, (_, k) => ({
      id: "i" + k,
      name: "Tétel " + k,
      unit: "db",
      quantity: "1",
      weight: "5",
    }));
    x.bidders = Array.from({ length: 4 }, (_, k) => ({
      id: "b" + k,
      name: "Fiktív " + k,
      status: "submitted",
      compliance: "pass",
      checks: { r: { status: "pass" } },
      versions: [
        {
          id: "v" + k,
          prices: Object.fromEntries(
            x.items.map((i) => [i.id, String(10 + k)]),
          ),
        },
      ],
    }));
    expect(evaluate(x).ranked).toHaveLength(4);
    expect(evaluate(x).ranked[0].total).toBe("200");
  });
  it("90 + 3 × 10/3 pontosan 100 pont", () => {
    const x = p("points");
    x.items = ["90", "10/3", "10/3", "10/3"].map((weight, k) => ({
      id: "i" + k,
      name: "Tétel",
      unit: "db",
      quantity: "1",
      weight,
    }));
    x.bidders = x.bidders.slice(0, 2).map((b, k) => ({
      ...b,
      versions: [
        {
          id: "v" + k,
          prices: Object.fromEntries(
            x.items.map((i) => [i.id, k ? "120" : "100"]),
          ),
        },
      ],
    }));
    expect(evaluate(x).ranked[0].value).toBe("100");
    expect(evaluate(x).ranked[1].value).toBe("84");
  });
  it("a K-szegély ellenőrzési cél 100 és 85,722 fiktív árakkal", () => {
    const x = p("points");
    x.items = ["90", "10/3", "10/3", "10/3"].map((weight, k) => ({
      id: "i" + k,
      name: "Fiktív tétel",
      unit: "db",
      quantity: "1",
      weight,
    }));
    x.bidders = x.bidders
      .slice(0, 2)
      .map((b, k) => ({
        ...b,
        versions: [
          {
            id: "v" + k,
            prices: Object.fromEntries(
              x.items.map((i) => [i.id, k ? "96000" : "81722"]),
            ),
          },
        ],
      }));
    expect(evaluate(x).ranked.map((r) => r.value)).toEqual(["100", "85.722"]);
  });
  it("fél felfelé kerekít kizárólag megjelenítéshez", () => {
    expect(number("1.2345").fixed(3)).toBe("1.235");
    expect(number("10/3").fixed(3)).toBe("3.333");
    expect(number("1/2").fixed(0)).toBe("1");
  });
});
