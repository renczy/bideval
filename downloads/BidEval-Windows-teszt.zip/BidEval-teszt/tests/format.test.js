import { it, expect } from "vitest";
import { money } from "../src/format.ts";
it("pénzügyi megjelenítés nem veszít pontosságot nagy összegeknél", () => {
  expect(money("9007199254740993.4445", 3)).toBe("9 007 199 254 740 993,445");
  expect(money("10/3", 3)).toBe("3,333");
  expect(money(undefined)).toBe("—");
});
