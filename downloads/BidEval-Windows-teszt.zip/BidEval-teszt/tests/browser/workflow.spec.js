import { test, expect } from "@playwright/test";
test("magyar bejelentkezési felület és védett munkatér", async ({ page }) => {
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Adminisztrátor létrehozása" }),
  ).toBeVisible();
  await page.getByLabel("Telepítési token").fill("wrong");
  await page.getByLabel("E-mail-cím").fill("fiktiv@example.test");
  await page.getByLabel("Jelszó", { exact: true }).fill("FiktivJelszo123!");
  await page.getByRole("button", { name: "Fiók létrehozása" }).click();
  await expect(page.getByRole("alert")).toContainText(
    "Érvénytelen telepítési token",
  );
});
test("teljes felületi folyamat három ajánlattevővel, rangsorral és exporttal", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByLabel("Telepítési token")
    .fill("LOCAL-E2E-ONLY-NOT-A-PRODUCTION-CREDENTIAL");
  await page.getByLabel("E-mail-cím").fill("admin@example.test");
  await page.getByLabel("Jelszó", { exact: true }).fill("FiktivJelszo123!");
  await page.getByRole("button", { name: "Fiók létrehozása" }).click();
  await expect(page.getByRole("heading", { name: "Áttekintés" })).toBeVisible();
  await page.getByRole("button", { name: "Új beszerzés" }).click();
  await page.getByLabel("Beszerzés tárgya").fill("Fiktív tesztbeszerzés");
  await page.getByLabel("Eljárás azonosítója").fill("E2E-001");
  await page.getByLabel("Kezdeményező szervezet").fill("Fiktív osztály");
  await page.getByLabel("Becsült nettó érték (Ft)").fill("5000");
  await page.getByRole("button", { name: "Beszerzés létrehozása" }).click();
  await page.getByRole("button", { name: "Új tétel" }).click();
  const row = page.getByRole("row").nth(1);
  await row.locator("input").nth(0).fill("Granulátum");
  await row.locator("input").nth(1).fill("10");
  await page.getByRole("button", { name: "Feltételek mentése" }).click();
  await expect(page.getByText("Művelet folyamatban…")).not.toBeVisible();
  await page
    .getByRole("button", { name: "Mentett feltételek véglegesítése" })
    .click();
  await expect(page.getByText("Véglegesített módszer ·")).toBeVisible();
  await page.getByRole("button", { name: "2. Ajánlatok" }).click();
  for (const n of ["Fiktív Alfa", "Fiktív Béta", "Fiktív Gamma"]) {
    await page.getByPlaceholder("Ajánlattevő neve").fill(n);
    await page.getByRole("button", { name: "Partner felvétele" }).click();
    await expect(
      page.getByRole("heading", { name: n, exact: true }),
    ).toBeVisible();
  }
  for (const [i, n] of [
    "Fiktív Alfa",
    "Fiktív Béta",
    "Fiktív Gamma",
  ].entries()) {
    const panel = page
      .locator(".panel")
      .filter({ has: page.getByRole("heading", { name: n, exact: true }) });
    await panel.getByLabel("Ajánlat státusza").selectOption("submitted");
    await panel
      .getByLabel("Összesített bírálói megfelelőségi megállapítás")
      .selectOption("pass");
    await page.getByLabel(n + " Granulátum ára").fill(String(100 + i * 20));
    await panel
      .getByRole("button", { name: "Új ajánlatverzió mentése" })
      .click();
    await expect(panel.getByText("1 ajánlatverzió")).toBeVisible();
  }
  await page.getByRole("button", { name: "3. Bírálat és döntés" }).click();
  await expect(
    page.getByRole("heading", { name: "Értékelési rangsor" }),
  ).toBeVisible();
  await page
    .getByLabel("Szakmai és pénzügyi indokolás")
    .fill(
      "A megfelelő ajánlatok közül a legalacsonyabb összesített árat adta.",
    );
  await page
    .getByLabel("Nyertes ajánlat főbb műszaki tartalma")
    .fill("10 zsák granulátum");
  await page.getByLabel("Bíráló neve").fill("Teszt Bíráló");
  await page.getByLabel("Munkakör", { exact: true }).fill("Beszerző");
  await page.getByLabel("Készítés helye").fill("Tesztváros");
  await page.getByLabel("Bírálat ideje").fill("2026-10-11");
  await page
    .getByLabel("Szerződés tervezett futamideje")
    .fill("2026. november");
  await page.getByLabel("Szerződés tervezett nettó értéke (Ft)").fill("1000");
  await page
    .getByRole("button", { name: "Döntési javaslat jóváhagyása" })
    .click();
  await expect(
    page.getByRole("heading", { name: "Jóváhagyott döntési javaslat" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "4. Dokumentumok" }).click();
  const d = page.waitForEvent("download");
  await page.getByRole("button", { name: "Összehasonlító Excel" }).click();
  await expect((await d).suggestedFilename()).toBe("osszehasonlitas.xlsx");
  await expect(
    page.getByText("Az eredeti, jóváhagyott DOCX-sablon hiányzik."),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/bideval-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(
    page.getByRole("button", { name: "Összehasonlító Excel" }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: "test-results/bideval-mobile.png",
    fullPage: true,
  });
  await page.reload();
  await expect(page.getByText("Fiktív tesztbeszerzés")).toBeVisible();
});

test("eredeti céges sablonból DOCX és PDF export a kezelőfelületen", async ({
  page,
}) => {
  const { existsSync } = await import("node:fs");
  test.skip(
    !existsSync(".data/prepared-template.docx"),
    "A privát eredeti sablon külön szükséges; nem kerül Gitbe.",
  );
  await page.goto("/");
  await page.getByLabel("E-mail-cím").fill("admin@example.test");
  await page.getByLabel("Jelszó", { exact: true }).fill("FiktivJelszo123!");
  await page
    .getByRole("button", { name: "Bejelentkezés", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: "Áttekintés" })).toBeVisible();
  await page
    .getByRole("button", { name: "Adminisztráció", exact: true })
    .click();
  await page
    .locator('input[name="file"]')
    .setInputFiles(".data/prepared-template.docx");
  await page.getByRole("checkbox").check();
  await page.getByRole("button", { name: "Sablonverzió mentése" }).click();
  await expect(page.getByText("Művelet folyamatban…")).not.toBeVisible();
  await page.getByRole("button", { name: "Dokumentumok", exact: true }).click();
  await expect(
    page.getByText("prepared-template.docx", { exact: false }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Beszerzések", exact: true }).click();
  await page.getByText("Fiktív tesztbeszerzés", { exact: true }).click();
  await page.getByRole("button", { name: "4. Dokumentumok" }).click();
  await page.getByLabel("Sablonverzió").selectOption({ index: 1 });
  const docx = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Bírálati lap (DOCX)", exact: true })
    .click();
  expect((await docx).suggestedFilename()).toBe("Biralati-lap.docx");
  const pdf = page.waitForEvent("download");
  await page.getByRole("button", { name: "PDF-előnézet", exact: true }).click();
  expect((await pdf).suggestedFilename()).toBe("Biralati-lap.pdf");
});
