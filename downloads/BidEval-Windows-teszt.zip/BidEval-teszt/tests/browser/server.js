import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
const dir = mkdtempSync(path.join(tmpdir(), "bideval-e2e-"));
const p = spawn(process.execPath, ["server/index.js"], {
  stdio: "inherit",
  env: {
    ...process.env,
    PORT: "3011",
    BIDEVAL_FRONTEND_ORIGIN: "http://127.0.0.1:4173",
    BIDEVAL_DATA_DIR: dir,
    BIDEVAL_BOOTSTRAP_TOKEN: "LOCAL-E2E-ONLY-NOT-A-PRODUCTION-CREDENTIAL",
  },
});
function stop() {
  p.kill("SIGTERM");
}
process.on("SIGTERM", stop);
process.on("SIGINT", stop);
p.on("exit", (code) => {
  rmSync(dir, { recursive: true, force: true });
  process.exit(code || 0);
});
