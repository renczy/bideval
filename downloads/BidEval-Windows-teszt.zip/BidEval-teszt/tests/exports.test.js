import { it, expect } from "vitest";
import { evaluate } from "../server/evaluation.js";
import { justification } from "../server/exports.js";
it("súlyozott döntési indokolás elkülöníti a matematikai elsőt és a nettó ár szerinti elsőt", () => {
  const p = {
    method: "weighted",
    minimum: "1",
    items: [
      { id: "a", name: "Termék", unit: "db", quantity: "1", weight: "90" },
      {
        id: "b",
        name: "Szállítás",
        unit: "alkalom",
        quantity: "1",
        weight: "10/3",
      },
    ],
    requirements: [],
    bidders: [
      {
        id: "x",
        name: "Fiktív Alfa",
        status: "submitted",
        compliance: "pass",
        checks: {},
        versions: [{ id: "v1", prices: { a: "100", b: "100" } }],
      },
      {
        id: "y",
        name: "Fiktív Béta",
        status: "submitted",
        compliance: "pass",
        checks: {},
        versions: [{ id: "v2", prices: { a: "120", b: "0" } }],
      },
    ],
  };
  const e = evaluate(p);
  expect(e.ranked[0].id).toBe("x");
  const reason = justification(p, e, "x");
  expect(reason).toContain("súlyozott összehasonlító érték nem szerződéses ár");
  expect(reason).toContain(
    "legalacsonyabb nettó összértékű értékelhető ajánlatot Fiktív Béta adta",
  );
});
