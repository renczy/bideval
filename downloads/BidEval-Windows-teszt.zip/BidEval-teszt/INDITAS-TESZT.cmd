@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Eloszor telepitsd a Node.js 24 LTS verziot: https://nodejs.org/
 echo Ezutan kattints ujra erre az inditofajlra.
 pause
 exit /b 1
)
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 (
 echo Node.js 24 vagy ujabb szukseges: https://nodejs.org/
 pause
 exit /b 1
)
if not exist node_modules\express (
 echo Elso inditas: a fuggosegek telepitese internetkapcsolattal...
 call npm ci --omit=dev --no-audit --no-fund --cache "%~dp0npm-cache"
 if errorlevel 1 (
  echo A telepites nem sikerult. A hiba szoveget masold a hibajelentesbe.
  pause
  exit /b 1
 )
)
node inditas-teszt.mjs
pause
