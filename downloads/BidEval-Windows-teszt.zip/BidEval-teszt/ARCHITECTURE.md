# Architektúra

## Jelenleg működő rendszer

React 19 + TypeScript + Vite SPA, magyar felülettel. A frontend azonos eredetű `/api` végpontokon kommunikál az Express 5/Node 24 szerverrel. A szerver SQLite-adatbázist használ, ideértve a privát dokumentumok bináris tartalmát. Nincs fizetős AI API és külső vállalati adatküldés.

A `.data` könyvtár nem része Gitnek. A scrypt jelszóhash sózott; a munkamenet véletlen, szerveroldalon csak SHA-256 hashként tárolt, 8 órás, HttpOnly/SameSite Strict cookie. A hozzáférés visszavonása és a jelszócsere törli a munkameneteket. Az admin minden ügyet elér; a bíráló csak saját/hozzárendelt ügyeket módosíthat, a megtekintő csak olvashat. Nyilvános regisztráció nincs.

A tranzakciók a feltételek mentését, zárolását, ajánlatverziókat és auditot együtt rögzítik. A setup véglegesítése után a szerver sem fogad el feltételmódosítást. A jóváhagyás után az árak, megfelelőség és partnerek zároltak. Az exportok ugyanazt a változtathatatlan pillanatképet olvassák.

A pénzügyi számítás `server/rational.js`: BigInt számláló/nevező, pontos alapműveletek és összehasonlítás. A visszaadott decimális szöveg legfeljebb 80 tizedesjegy; a rangsorolás az exactValue mezőn történik. A webes és Excel-megjelenítés véges pontosságú. Excelben valódi képletek és a szerver által kiszámított cache-értékek szerepelnek; Excel lebegőpontos újraszámításánál minimális eltérés lehetséges. Közel azonos eredményeknél a hivatalos rangsor a szerver pontos eredménye.

DOCX: PizZip + Docxtemplater. A meglévő ZIP-részeket és run-formázást használja; új modern dokumentumot nem állít elő. A sablon előkészítése során az admin jóváhagyása és a korábbi ügyadatok/aláírásképek eltávolítása szükséges. A program nem tudja önállóan eldönteni egy képről, hogy logó vagy aláírás. Az eredeti referencia rendelkezésre áll; a mezőillesztés és a fiktív dokumentumok helyi vizuális regressziója elkészült. Microsoft Wordben és a vállalati jóváhagyási folyamatban további elfogadás szükséges. A PDF-et a helyi LibreOffice készíti elkülönített ideiglenes profillal, időkorláttal és automatikus takarítással.

## Cél felhős rendszer – még nincs bekötve

Cloudflare Pages statikus frontend; Supabase Auth meghívásos hozzáféréssel, PostgreSQL normalizált modellel és RLS-sel; privát Storage bucket; Edge Functions tranzakciós üzleti műveletekhez. A DOCX és az XLSX előállítása azonos pillanatképből történik. A PDF-renderelés külön, konténeres LibreOffice komponensben javasolt, privát eléréssel és korlátozott erőforrásokkal. A renderelési komponens nem küldhet bizalmas dokumentumot nyilvános külső szolgáltatásba külön jóváhagyás nélkül.

A felhős átállás hátralévő feladatai: adapterek, Auth-integráció, meghívás/visszaállítás, Storage feltöltés/letöltés, tranzakciós RPC/Edge Functions, RLS integrációs tesztek. Az előkészített SQL nem igazolja ezeket a képességeket.

## Fejlesztési sorrend

1. Helyi munkafolyamat és regressziós tesztek (elkészült).
2. Eredeti minták elemzése és sablon előkészítése (elkészült; adminisztrátori hatályossági jóváhagyás szükséges).
3. Supabase-integráció és RLS-validáció (projekt és konfiguráció szükséges).
4. Helyi renderelés, vizuális regresszió és dinamikus táblázatfolytatás (elkészült); Microsoft Word elfogadás.
5. Éles hardening, felhasználói elfogadás, majd külön jóváhagyott publikálás.
